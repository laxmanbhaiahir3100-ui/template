import random
import string
import asyncio
import aiohttp
import json
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# 🔹 Telegram Bot Token
BOT_TOKEN = "7605916679:AAG8o4PNOCy0-TerrpCVBzQFcFcC7kL7NbU"

# 🔹 Admin ID
ADMIN_ID = 1386134836

# 🔹 Mail.tm API URL
MAIL_API = "https://api.mail.tm"

# ✅ Store Generated Emails
user_emails = {}

# ✅ User Database (JSON File)
USER_DB = "users.json"

# ✅ Domains cache
domains_cache = []
domains_cache_time = 0
CACHE_DURATION = 3600  # 1 hour

# ✅ Load Users Data
def load_users():
    try:
        with open(USER_DB, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return {}

# ✅ Save Users Data
def save_users(users):
    with open(USER_DB, "w") as file:
        json.dump(users, file, indent=4)

# ✅ Fetch domains from Mail.tm
async def fetch_domains():
    global domains_cache, domains_cache_time
    current_time = asyncio.get_event_loop().time()

    # Return cached domains if still valid
    if domains_cache and (current_time - domains_cache_time) < CACHE_DURATION:
        return domains_cache

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{MAIL_API}/domains") as response:
                if response.status == 200:
                    data = await response.json()
                    domains = [domain["domain"] for domain in data.get("hydra:member", [])]
                    if domains:
                        domains_cache = domains
                        domains_cache_time = current_time
                        return domains
    except Exception as e:
        print(f"Error fetching domains: {e}")

    # Fallback to default domain if API fails
    return ["deltajohnsons.com"] if not domains_cache else domains_cache

# ✅ Start Command
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.message.from_user
    users = load_users()

    if str(user.id) not in users:
        users[str(user.id)] = {
            "username": user.username if user.username else "N/A",
            "id": user.id
        }
        save_users(users)
        await context.bot.send_message(
            chat_id=ADMIN_ID,
            text=f"👑 **🚀 New User Alert!**\n"
                 f"👤 Username: @{user.username if user.username else 'N/A'}\n"
                 f"🆔 ID: {user.id}\n"
                 f"📊 Total Users: {len(users)}"
        )

    # Attractive welcome message with formatting
    welcome_text = (
        "🌟 **🎉 Welcome to Temp Mail Pro!** 🎉 **🌟\n\n"
        "💫 **Your premium temporary email service**\n\n"
        "🔹 **📧 Generate Email** - Get a fresh temporary email\n"
        "🔹 **📩 Check Inbox** - See your received messages\n"
        "🔹 **🔗 Join Community** - Connect with our team\n"
        "🔹 **⚙️ More Features** - Explore advanced options\n\n"
        "💎 **Premium Features:**\n"
        "• Instant email generation\n"
        "• Real-time notifications\n"
        "• Multiple domain support\n"
        "• Secure & private\n\n"
        "🚀 **Ready to get started?**"
    )

    keyboard = [
        [
            InlineKeyboardButton("📧 **Generate Email**", callback_data="generate_email"),
            InlineKeyboardButton("📩 **Check Inbox**", callback_data="check_inbox")
        ],
        [
            InlineKeyboardButton("🔄 **New Mail**", callback_data="generate_email"),
            InlineKeyboardButton("📋 **Copy Email**", callback_data="copy_email")
        ],
        [
            InlineKeyboardButton("🌐 **Domains**", callback_data="show_domains"),
            InlineKeyboardButton("🔗 **Join Community**", url="https://t.me/modverse_online")
        ],
        [
            InlineKeyboardButton("⚙️ **Settings**", callback_data="settings"),
            InlineKeyboardButton("❓ **Help**", callback_data="help")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        welcome_text,
        parse_mode="Markdown",
        reply_markup=reply_markup
    )

# � Generate Email with random domain selection
async def generate_email(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id

    # Show loading animation
    await query.edit_message_text("🔄 **Generating your premium email...**", parse_mode="Markdown")

    # Fetch available domains
    domains = await fetch_domains()
    selected_domain = random.choice(domains) if domains else "deltajohnsons.com"

    # Generate random email
    username = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
    random_email = f"{username}@{selected_domain}"
    email_password = "".join(random.choices(string.ascii_letters + string.digits, k=12))

    payload = {"address": random_email, "password": email_password}

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(f"{MAIL_API}/accounts", json=payload) as response:
                data = await response.json()

                if "id" in data:
                    # Get token for the email
                    async with session.post(f"{MAIL_API}/token", json={"address": random_email, "password": email_password}) as token_resp:
                        token_data = await token_resp.json()
                        auth_token = token_data.get("token")

                    user_emails[user_id] = {
                        "email": random_email,
                        "token": auth_token,
                        "last_message_id": None,
                        "password": email_password,
                        "domain": selected_domain,
                        "created_at": asyncio.get_event_loop().time()
                    }

                    # Success message with attractive formatting
                    success_text = (
                        f"✅ **🎉 Email Generated Successfully!** 🎉\n\n"
                        f"📧 **Your Email:** `{random_email}`\n"
                        f"🔐 **Password:** `{email_password}`\n"
                        f"🌐 **Domain:** {selected_domain}\n"
                        f"⏰ **Created:** Just now\n\n"
                        f"💡 **Pro Tips:**\n"
                        f"• Use the buttons below to manage your email\n"
                        f"• Messages appear automatically\n"
                        f"• Emails are valid for extended periods\n"
                        f"• All data is secure and private"
                    )

                    keyboard = [
                        [
                            InlineKeyboardButton("📩 **Check Inbox**", callback_data="check_inbox"),
                            InlineKeyboardButton("📋 **Copy Email**", callback_data="copy_email")
                        ],
                        [
                            InlineKeyboardButton("🔄 **Refresh Inbox**", callback_data="check_inbox"),
                            InlineKeyboardButton("🆕 **New Email**", callback_data="generate_email")
                        ],
                        [
                            InlineKeyboardButton("📊 **Email Stats**", callback_data="email_stats"),
                            InlineKeyboardButton("🗑️ **Delete Email**", callback_data="delete_email")
                        ],
                        [
                            InlineKeyboardButton("🏠 **Main Menu**", callback_data="main_menu")
                        ]
                    ]
                    reply_markup = InlineKeyboardMarkup(keyboard)

                    await query.edit_message_text(
                        success_text,
                        parse_mode="Markdown",
                        reply_markup=reply_markup
                    )
                else:
                    error_text = (
                        f"❌ **Generation Failed**\n\n"
                        f"Sorry! We couldn't generate your email right now.\n"
                        f"This might be due to:\n"
                        f"• Temporary service issues\n"
                        f"• Domain availability\n"
                        f"• Network connectivity\n\n"
                        f"🔄 **Please try again in a moment.**"
                    )
                    await query.edit_message_text(
                        error_text,
                        parse_mode="Markdown"
                    )
    except Exception as e:
        error_text = (
            f"❅ **Connection Error**\n\n"
            f"We're having trouble connecting to our email service.\n"
            f"Please check your connection and try again.\n\n"
            f"🔧 Error: {str(e)[:50]}..."
        )
        await query.edit_message_text(
            error_text,
            parse_mode="Markdown"
        )

# ✅ Check Inbox with attractive formatting
async def check_inbox(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id=None):
    if update:
        query = update.callback_query
        await query.answer()
        user_id = query.from_user.id

    if user_id not in user_emails:
        if update:
            await query.message.reply_text(
                "❌ **Oops!** You need to generate an email first!\n\n"
                f"💡 **Tip:** Click on '📧 Generate Email' to get started.",
                parse_mode="Markdown"
            )
        return

    email_data = user_emails[user_id]
    headers = {"Authorization": f"Bearer {email_data['token']}"}

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{MAIL_API}/messages", headers=headers) as response:
                data = await response.json()

                total_messages = data.get("hydra:totalItems", 0)

                if total_messages > 0:
                    # Show loading for latest message
                    if update:
                        await query.edit_message_text("🔍 **Fetching your latest message...**", parse_mode="Markdown")

                    latest_message_id = data["hydra:member"][0]["id"]

                    if email_data.get("last_message_id") == latest_message_id and update:
                        # No new messages
                        return

                    # Fetch the latest message
                    async with session.get(f"{MAIL_API}/messages/{latest_message_id}", headers=headers) as msg_response:
                        message_data = await msg_response.json()
                        sender = message_data.get("from", {}).get("address", "Unknown")
                        subject = message_data.get("subject", "No Subject")
                        body = message_data.get("text", "No Body")
                        created_at = message_data.get("createdAt", "Unknown")

                        # Truncate body if too long
                        display_body = body[:200] + "..." if len(body) > 200 else body

                        message_text = (
                            f"📬 **📨 New Message Received** 📬\n\n"
                            f"📧 **From:** `{sender}`\n"
                            f"📝 **Subject:** `{subject}`\n"
                            f"🕐 **Received:** {created_at[:16] if created_at != 'Unknown' else 'Just now'}\n\n"
                            f"💬 **Message:**\n"
                            f"```\n{display_body}\n```\n\n"
                            f"📊 **Inbox Stats:** {total_messages} message{'s' if total_messages != 1 else ''} total\n"
                        )

                        if update:
                            keyboard = [
                                [
                                    InlineKeyboardButton("🔄 **Check Again**", callback_data="check_inbox"),
                                    InlineKeyboardButton("📧 **Compose Reply**", callback_data="compose_reply")
                                ],
                                [
                                    InlineKeyboardButton("📥 **View All**", callback_data="view_all_messages"),
                                    InlineKeyboardButton("🗑️ **Delete Message**", callback_data="delete_message")
                                ],
                                [
                                    InlineKeyboardButton("🏠 **Main Menu**", callback_data="main_menu")
                                ]
                            ]
                            reply_markup = InlineKeyboardMarkup(keyboard)

                            await query.edit_message_text(
                                message_text,
                                parse_mode="Markdown",
                                reply_markup=reply_markup
                            )

                        # Update last message ID
                        if update:
                            user_emails[user_id]["last_message_id"] = latest_message_id

                else:
                    # No messages
                    no_messages_text = (
                        f"📭 **Your Inbox is Empty**\n\n"
                        f"📧 **Email:** `{email_data['email']}`\n"
                        f"📭 **Messages:** 0\n\n"
                        f"💡 **Waiting for incoming messages...**\n"
                        f"Share your email address to start receiving!\n\n"
                        f"🔄 **Auto-refresh enabled** - checks every 15 seconds"
                    )

                    if update:
                        keyboard = [
                            [
                                InlineKeyboardButton("𝔼 **Refresh Now**", callback_data="check_inbox"),
                                InlineKeyboardButton("📧 **Get New Email**", callback_data="generate_email")
                            ],
                            [
                                InlineKeyboardButton("📤 **Send Test Email**", callback_data="send_test_email"),
                                InlineKeyboardButton("📊 **Inbox Stats**", callback_data="inbox_stats")
                            ],
                            [
                                InlineKeyboardButton("🏠 **Main Menu**", callback_data="main_menu")
                            ]
                        ]
                        reply_markup = InlineKeyboardMarkup(keyboard)

                        await query.edit_message_text(
                            no_messages_text,
                            parse_mode="Markdown",
                            reply_markup=reply_markup
                        )

    except Exception as e:
        error_text = (
            f"❌ **Inbox Error**\n\n"
            f"We encountered an issue while checking your inbox.\n"
            f"This is usually temporary - please try again.\n\n"
            f"🔧 Technical details: {str(e)[:50]}..."
        )

        if update:
            await query.edit_message_text(
                error_text,
                parse_mode="Markdown"
            )

# ✅ Auto Inbox Checker with better error handling
async def auto_check_inbox(context: ContextTypes.DEFAULT_TYPE):
    user_ids = list(user_emails.keys())
    for user_id in user_ids:
        try:
            await check_inbox(None, context, user_id)
        except Exception as e:
            print(f"Auto-check error for user {user_id}: {e}")
            # Remove problematic entries
            if user_id in user_emails:
                del user_emails[user_id]
    await asyncio.sleep(15)  # Increased interval to reduce load

# ✅ Admin Command: Users with attractive formatting
async def get_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.from_user.id != ADMIN_ID:
        await update.message.reply_text(
            "🚫 **Access Denied**\n\n"
            "This command is restricted to administrators only.\n"
            f"Your ID: {update.message.from_user.id}\n"
            f"Admin ID: {ADMIN_ID}",
            parse_mode="Markdown"
        )
        return

    users = load_users()
    total_users = len(users)

    if total_users == 0:
        user_list = "No users yet 🤷‍♂️"
    else:
        # Show first 10 users
        user_items = list(users.items())[:10]
        user_list = "\n".join([
            f"{(i+1):2d}. @{u['username'] if u['username'] else 'N/A'} (ID: {uid})"
            for i, (uid, u) in enumerate(user_items)
        ])
        if total_users > 10:
            user_list += f"\n...and {total_users - 10} more users"

    admin_text = (
        f"👑 Admin Panel - User Statistics 👑\n\n"
        f"👥 Total Registered Users: {total_users}\n\n"
        f"📧 Active Sessions: {len(user_emails)}\n"
        f"⏰ Last Updated: Just now\n\n"
        f"💡 Available Admin Commands:\n"
        f"/users - View user statistics\n"
        f"/bcast <message> - Broadcast to all users\n"
        f"/stats - Detailed system statistics"
    )

    await update.message.reply_text(admin_text, parse_mode="Markdown")

# ✅ Admin Command: Broadcast with confirmation
async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.from_user.id != ADMIN_ID:
        await update.message.reply_text(
            "🚫 **Access Denied**\n\n"
            "Broadcast feature is admin-only.",
            parse_mode="Markdown"
        )
        return

    if not context.args:
        await update.message.reply_text(
            "⚠️ **Broadcast Usage**\n\n"
            "Please provide a message to broadcast.\n\n"
            "📝 **Example:**\n"
            "`/bcast Hello everyone! New feature available!`\n\n"
            "💡 **Tips:**\n"
            f"• Maximum {len(context.args) if context.args else 0} words provided\n"
            "• Messages are sent to all registered users\n"
            "• Delivery may take a moment for large user bases\n"
        )
        return

    message = " ".join(context.args)
    users = load_users()
    sent_count = 0
    failed_count = 0

    # Send broadcast messages
    for user_id in users.keys():
        try:
            await context.bot.send_message(chat_id=int(user_id), text=message)
            sent_count += 1
            # Small delay to avoid rate limiting
            await asyncio.sleep(0.1)
        except Exception as e:
            failed_count += 1
            print(f"Failed to send to user {user_id}: {e}")

    # Confirmation message
    broadcast_text = (
        f"📢 **Broadcast Complete** 📢\n\n"
        f"✅ **Successfully Sent:** {sent_count} users\n"
        f"❌ **Failed Delivery:** {failed_count} users\n"
        f"📊 **Total Attempted:** {sent_count + failed_count} users\n\n"
        f"📝 **Message:**\n"
        f"\"{message[:100]}{'...' if len(message) > 100 else ''}\"\n\n"
        f"⏰ **Completed:** Just now"
    )

    await update.message.reply_text(broadcast_text, parse_mode="Markdown")

# ✅ Help Command
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = (
        f"📚 **Temp Mail Pro - Help Center** 📚\n\n"
        f"🤖 **About This Bot:**\n"
        f"Advanced temporary email service with premium features\n\n"
        f"🔧 **Available Commands:**\n"
        f"/start - Initialize the bot and see main menu\n"
        f"/help - Show this help message\n"
        f"/users - [Admin] View user statistics\n"
        f"/bcast <msg> - [Admin] Broadcast message to users\n"
        f"/stats - [Admin] System performance stats\n\n"
        f"💎 **Premium Features:**\n"
        f"• 🌐 Multiple domain support\n"
        f"• 🔐 Secure email generation\n"
        f"• 📱 Mobile-optimized interface\n"
        f"• ⚡ Real-time notifications\n"
        f"• 🛡️ Privacy-focused\n\n"
        f"📞 **Need More Help?**\n"
        f"Contact: @modverse_online\n"
        f"Community: https://t.me/modverse_online\n\n"
        f"💡 **Pro Tip:** Use the inline buttons for fastest navigation!"
    )

    if update.message:
        await update.message.reply_text(help_text, parse_mode="Markdown")
    else:
        query = update.callback_query
        await query.answer()
        await query.edit_message_text(help_text, parse_mode="Markdown",
                                    reply_markup=InlineKeyboardMarkup([[
                                        InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")
                                    ]]))

# ✅ Stats Command (Admin)
async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.from_user.id != ADMIN_ID:
        await update.message.reply_text(
            "🚫 **Access Denied**\n\n"
            "Statistics feature is admin-only.",
            parse_mode="Markdown"
        )
        return

    users = load_users()
    total_users = len(users)
    active_sessions = len(user_emails)

    # Calculate average email age
    current_time = asyncio.get_event_loop().time()
    if user_emails:
        ages = [current_time - data.get("created_at", current_time) for data in user_emails.values()]
        avg_age_minutes = sum(ages) / len(ages) / 60 if ages else 0
    else:
        avg_age_minutes = 0

    stats_text = (
        f"📈 **System Statistics** 📈\n\n"
        f"👥 **User Analytics:**\n"
        f"• Total Registered: {total_users}\n"
        f"• Active Sessions: {active_sessions}\n"
        f"• Avg. Session Age: {avg_age_minutes:.1f} min\n\n"
        f"📧 **Email Service:**\n"
        f"• Available Domains: {len(domains_cache) if domains_cache else 0}\n"
        f"• Cache Status: {'Fresh' if domains_cache and (current_time - domains_cache_time) < 1800 else 'Stale'}\n"
        f"• Service Status: {'Online' if domains_cache else 'Limited'}\n\n"
        f"⚡ **Performance:**\n"
        f"• Bot Uptime: Running\n"
        f"• Memory Usage: Optimal\n"
        f"• Response Time: Fast\n\n"
        f"🔧 **Technical:**\n"
        f"• Python Version: 3.13+\n"
        f"• Library: python-telegram-bot 22.7\n"
        f"• API: Mail.tm v1\n\n"
        f"⏰ **Last Updated:** Just now"
    )

    await update.message.reply_text(stats_text, parse_mode="Markdown",
                                  reply_markup=InlineKeyboardMarkup([[
                                      InlineKeyboardButton("🔄 Refresh Stats", callback_data="refresh_stats"),
                                      InlineKeyboardButton("🏠 Main Window", callback_data="main_menu")
                                  ]]))

# ✅ Button Handler with enhanced functionality
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global domains_cache, domains_cache_time
    query = update.callback_query
    await query.answer()

    if query.data == "generate_email":
        await generate_email(update, context)
    elif query.data == "check_inbox":
        await check_inbox(update, context)
    elif query.data == "copy_email":
        user_id = query.from_user.id
        email = user_emails.get(user_id, {}).get("email", "No Email Found")
        await query.message.reply_text(
            f"📋 **Email Copied to Clipboard!**\n\n"
            f"`{email}`\n\n"
            f"💡 Tip: Long-press to copy manually if needed",
            parse_mode="Markdown"
        )
    elif query.data == "main_menu":
        # Edit the current message to show the main menu
        user = query.from_user
        users = load_users()

        if str(user.id) not in users:
            users[str(user.id)] = {
                "username": user.username if user.username else "N/A",
                "id": user.id
            }
            save_users(users)
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=f"👑 **🚀 New User Alert!**\n"
                     f"👤 Username: @{user.username if user.username else 'N/A'}\n"
                     f"🆔 ID: {user.id}\n"
                     f"📊 Total Users: {len(users)}"
            )

        # Attractive welcome message with formatting
        welcome_text = (
            "🌟 **🎉 Welcome to Temp Mail Pro!** 🎉 **🌟\n\n"
            "💫 **Your premium temporary email service**\n\n"
            "🔹 **📧 Generate Email** - Get a fresh temporary email\n"
            "🔹 **📩 Check Inbox** - See your received messages\n"
            "🔹 **🔗 Join Community** - Connect with our team\n"
            "🔹 **⚙️ More Features** - Explore advanced options\n\n"
            "💎 **Premium Features:**\n"
            "• Instant email generation\n"
            "• Real-time notifications\n"
            "• Multiple domain support\n"
            "• Secure & private\n\n"
            "🚀 **Ready to get started?**"
        )

        keyboard = [
            [
                InlineKeyboardButton("📧 **Generate Email**", callback_data="generate_email"),
                InlineKeyboardButton("📩 **Check Inbox**", callback_data="check_inbox")
            ],
            [
                InlineKeyboardButton("🔄 **New Mail**", callback_data="generate_email"),
                InlineKeyboardButton("📋 **Copy Email**", callback_data="copy_email")
            ],
            [
                InlineKeyboardButton("🌐 **Domains**", callback_data="show_domains"),
                InlineKeyboardButton("🔗 **Join Community**", url="https://t.me/modverse_online")
            ],
            [
                InlineKeyboardButton("⚙️ **Settings**", callback_data="settings"),
                InlineKeyboardButton("❓ **Help**", callback_data="help")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        await query.edit_message_text(
            welcome_text,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
    elif query.data == "help":
        await help_command(update, context)
    elif query.data == "settings":
        settings_text = (
            f"⚙️ Bot Settings ⚙️\n\n"
            f"🔧 Current Configuration:\n"
            f"• Auto-check Interval: 15 seconds\n"
            f"• Domain Cache Duration: 1 hour\n"
            f"• Email Length: 10 characters\n"
            f"• Password Length: 12 characters\n"
            f"• Max Message Preview: 200 characters\n\n"
            f"🌐 Available Domains: {len(domains_cache) if domains_cache else 0} loaded\n"
            f"📧 Active Emails: {len(user_emails)} sessions\n\n"
            f"🔒 Privacy Settings:\n"
            f"• Messages auto-deleted after viewing: No\n"
            f"• Personal data stored: Minimal (ID, username only)\n"
            f"• Email content stored: Temporary (session only)\n"
            f"• Encryption: Transport layer (HTTPS)\n\n"
            f"💡 Note: Settings are optimized for best performance\n"
        )
        await query.edit_message_text(
            settings_text,
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Refresh Domains", callback_data="refresh_domains")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")]
            ])
        )
    elif query.data == "refresh_domains":
        domains_cache = []  # Clear cache to force refresh
        domains_cache_time = 0
        await query.answer("🔄 Refreshing domains...")
        # Re-fetch domains
        domains = await fetch_domains()
        await query.edit_message_text(
            f"✅ **Domains Refreshed!**\n\n"
            f"🌐 Found {len(domains)} available domains\n"
            f"📋 Sample: {', '.join(domains[:3])}{'...' if len(domains) > 3 else ''}\n\n"
            f"⏰ Cache updated - next refresh in 1 hour",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")
            ]])
        )
    elif query.data == "email_stats":
        user_id = query.from_user.id
        if user_id in user_emails:
            data = user_emails[user_id]
            age_seconds = asyncio.get_event_loop().time() - data.get("created_at", asyncio.get_event_loop().time())
            age_minutes = age_seconds / 60

            stats_text = (
                f"📊 **Email Statistics** 📊\n\n"
                f"📧 **Address:** `{data['email']}`\n"
                f"🌐 **Domain:** {data.get('domain', 'Unknown')}\n"
                f"⏰ **Age:** {age_minutes:.1f} minutes\n"
                f"🔐 **Status:** Active\n"
                f"📭 **Last Check:** Just now\n\n"
                f"💡 **Technical Info:**\n"
                f"• Token length: {len(data.get('token', ''))} chars\n"
                f"• Session ID: {user_id}\n"
                f"• Created: {int(data.get('created_at', 0))}"
            )
        else:
            stats_text = "❌ No email session found. Please generate an email first."

        await query.edit_message_text(
            stats_text,
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔄 Refresh", callback_data="email_stats"),
                InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")
            ]])
        )
    elif query.data == "delete_email":
        user_id = query.from_user.id
        if user_id in user_emails:
            email = user_emails[user_id]['email']
            del user_emails[user_id]
            await query.edit_message_text(
                f"🗑️ **Email Deleted Successfully**\n\n"
                f"📧 `{email}` has been permanently removed\n"
                f"💡 You can generate a new email anytime!\n\n"
                f"📊 **Remaining Sessions:** {len(user_emails)}",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("📧 New Email", callback_data="generate_email"),
                    InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")
                ]])
            )
        else:
            await query.edit_message_text(
                "❌ No active email to delete.",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")
                ]])
            )
    else:
        # Handle unknown callbacks gracefully
        await query.answer("Feature coming soon!", show_alert=True)

# ✅ Main Function
def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("users", get_users))
    app.add_handler(CommandHandler("stats", stats_command))
    app.add_handler(CommandHandler("bcast", broadcast))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.job_queue.run_repeating(auto_check_inbox, interval=15, first=5)

    print("🚀 **Temp Mail Pro Bot Started Successfully!**")
    print("💎 Premium features enabled")
    print("🔒 Security features active")
    print("🌐 Domain fetching ready")
    print("📊 Statistics tracking enabled")

    app.run_polling()

if __name__ == "__main__":
    main()