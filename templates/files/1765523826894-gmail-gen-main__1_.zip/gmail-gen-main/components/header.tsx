"use client"

import { useState } from "react"
import Link from "next/link"
import { Mail } from "lucide-react"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="header">
      {/* Simple Centered Logo Only */}
      <div className="w-full flex justify-center">
        <Link href="/" className="logo flex items-center gap-2">
          <Mail className="h-6 w-6" />
          GMAIL GEN
        </Link>
      </div>

      {/* Mobile Navigation with Animation - Fixed links */}
      <div
        className={`fixed top-16 left-0 right-0 bg-black/95 backdrop-blur-sm md:hidden border-t border-purple-500/20 transform transition-all duration-300 ease-in-out z-50 ${
          isMenuOpen ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0"
        }`}
      >
        <nav className="flex flex-col p-4 gap-4">
          <Link
            href="/"
            className="text-white hover:text-purple-400 transition-colors py-2 px-4 rounded-lg hover:bg-purple-500/10"
            onClick={() => setIsMenuOpen(false)}
          >
            Home
          </Link>
          <Link
            href="/about"
            className="text-white hover:text-purple-400 transition-colors py-2 px-4 rounded-lg hover:bg-purple-500/10"
            onClick={() => setIsMenuOpen(false)}
          >
            About
          </Link>
          <Link
            href="/contact"
            className="text-white hover:text-purple-400 transition-colors py-2 px-4 rounded-lg hover:bg-purple-500/10"
            onClick={() => setIsMenuOpen(false)}
          >
            Contact
          </Link>
          <Link
            href="/terms"
            className="text-white hover:text-purple-400 transition-colors py-2 px-4 rounded-lg hover:bg-purple-500/10"
            onClick={() => setIsMenuOpen(false)}
          >
            Terms
          </Link>
          <Link
            href="/privacy"
            className="text-white hover:text-purple-400 transition-colors py-2 px-4 rounded-lg hover:bg-purple-500/10"
            onClick={() => setIsMenuOpen(false)}
          >
            Privacy
          </Link>
          <Link
            href="https://modverse.online"
            target="_blank"
            className="text-purple-400 hover:text-purple-300 transition-colors font-semibold py-2 px-4 rounded-lg hover:bg-purple-500/10"
            onClick={() => setIsMenuOpen(false)}
          >
            Modverse
          </Link>
        </nav>
      </div>
    </header>
  )
}
