import Link from "next/link"
import { Mail, MessageCircle, Globe } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-black/90 backdrop-blur-sm border-t border-purple-500/20 mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Mail className="h-6 w-6 text-purple-400" />
              <span className="text-xl font-bold text-white">Gmail Gen</span>
            </div>
            <p className="text-gray-400 text-sm">
              Free Gmail dot variation generator. Create unlimited email variations from one Gmail account.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-white font-semibold">Quick Links</h3>
            <div className="flex flex-col space-y-2">
              <Link href="/" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">
                Home
              </Link>
              <Link href="/about" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">
                About
              </Link>
              <Link href="/contact" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">
                Contact
              </Link>
            </div>
          </div>

          {/* Legal */}
          <div className="space-y-4">
            <h3 className="text-white font-semibold">Legal</h3>
            <div className="flex flex-col space-y-2">
              <Link href="/terms" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">
                Terms of Service
              </Link>
              <Link href="/privacy" className="text-gray-400 hover:text-purple-400 transition-colors text-sm">
                Privacy Policy
              </Link>
            </div>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h3 className="text-white font-semibold">Contact</h3>
            <div className="flex flex-col space-y-2">
              <a
                href="https://t.me/lakhan_lakhnotra"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-purple-400 transition-colors text-sm"
              >
                <MessageCircle className="h-4 w-4" />
                Telegram
              </a>
              <a
                href="https://t.me/modverse_online"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-purple-400 transition-colors text-sm"
              >
                <MessageCircle className="h-4 w-4" />
                Channel
              </a>
              <a
                href="https://modverse.online"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-purple-400 transition-colors text-sm"
              >
                <Globe className="h-4 w-4" />
                Modverse
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-purple-500/20 mt-8 pt-8 text-center">
          <p className="text-gray-400 text-sm">
            © 2024 Gmail Gen. Made with ❤️ by{" "}
            <a
              href="https://modverse.online"
              target="_blank"
              rel="noopener noreferrer"
              className="text-purple-400 hover:text-purple-300 transition-colors"
            >
              Modverse
            </a>
          </p>
        </div>
      </div>
    </footer>
  )
}
