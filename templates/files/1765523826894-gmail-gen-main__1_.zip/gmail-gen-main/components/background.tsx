"use client"

import { useEffect, useRef } from "react"

export default function Background() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    // Three.js background animation with performance optimizations
    const script = document.createElement("script")
    script.src = "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"
    script.onload = () => {
      // @ts-ignore
      const THREE = window.THREE

      const scene = new THREE.Scene()
      const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000)
      const renderer = new THREE.WebGLRenderer({
        canvas,
        alpha: true,
        antialias: false, // Disable for better performance
        powerPreference: "high-performance",
      })
      renderer.setSize(window.innerWidth, window.innerHeight)
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)) // Limit pixel ratio for performance

      const particles = new THREE.BufferGeometry()
      const particleCount = window.innerWidth < 768 ? 200 : 400 // Fewer particles on mobile
      const positions = new Float32Array(particleCount * 3)

      for (let i = 0; i < particleCount * 3; i++) {
        positions[i] = (Math.random() - 0.5) * 12
      }

      particles.setAttribute("position", new THREE.BufferAttribute(positions, 3))

      const material = new THREE.PointsMaterial({
        color: 0x6c5ce7,
        size: 0.08,
        transparent: true,
        opacity: 0.8,
      })
      const particleSystem = new THREE.Points(particles, material)
      scene.add(particleSystem)

      camera.position.z = 5

      let animationId: number

      function animate() {
        animationId = requestAnimationFrame(animate)
        particleSystem.rotation.y += 0.001
        particleSystem.rotation.x += 0.0005
        renderer.render(scene, camera)
      }

      animate()

      // Handle resize with debouncing
      let resizeTimeout: NodeJS.Timeout
      const handleResize = () => {
        clearTimeout(resizeTimeout)
        resizeTimeout = setTimeout(() => {
          camera.aspect = window.innerWidth / window.innerHeight
          camera.updateProjectionMatrix()
          renderer.setSize(window.innerWidth, window.innerHeight)
        }, 100)
      }

      window.addEventListener("resize", handleResize)

      return () => {
        window.removeEventListener("resize", handleResize)
        cancelAnimationFrame(animationId)
        clearTimeout(resizeTimeout)
      }
    }

    document.head.appendChild(script)

    return () => {
      if (document.head.contains(script)) {
        document.head.removeChild(script)
      }
    }
  }, [])

  return <canvas ref={canvasRef} className="fixed top-0 left-0 w-full h-full -z-10 gpu-accelerated" />
}
