# Dot Variation Generator

