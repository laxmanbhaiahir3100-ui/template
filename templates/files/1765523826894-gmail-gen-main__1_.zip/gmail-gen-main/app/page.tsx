"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Copy, Sparkles } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import Background from "@/components/background"

export default function GmailDotGenerator() {
  const [email, setEmail] = useState("")
  const [variations, setVariations] = useState<string[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const { toast } = useToast()

  const generateDotVariations = (username: string): string[] => {
    if (username.length <= 1) return [username]

    const variations = new Set<string>()
    const numPositions = username.length - 1
    const maxCombinations = Math.pow(2, numPositions)
    const combinationsToGenerate = Math.min(maxCombinations, 100)

    for (let i = 0; i < combinationsToGenerate; i++) {
      let variation = username[0]

      for (let pos = 0; pos < numPositions; pos++) {
        if (i & (1 << pos)) {
          variation += "."
        }
        variation += username[pos + 1]
      }

      variations.add(variation)
    }

    return Array.from(variations).sort()
  }

  const handleGenerate = () => {
    if (!email.trim()) {
      toast({
        title: "Error",
        description: "Please enter a Gmail address",
        variant: "destructive",
      })
      return
    }

    const gmailRegex = /^([a-zA-Z0-9]+)@gmail\.com$/i
    const match = email.trim().match(gmailRegex)

    if (!match) {
      toast({
        title: "Invalid Format",
        description: "Please enter a valid Gmail address (e.g., username@gmail.com)",
        variant: "destructive",
      })
      return
    }

    const username = match[1].toLowerCase()
    setIsGenerating(true)

    try {
      const dotVariations = generateDotVariations(username)

      if (dotVariations.length === 0) {
        setIsGenerating(false)
        return
      }

      const emailVariations = dotVariations.map((variation) => `${variation}@gmail.com`)
      setVariations(emailVariations)
      setIsGenerating(false)

      // Removed success notification as requested
    } catch (error) {
      console.error("Generation error:", error)
      setIsGenerating(false)
      toast({
        title: "Error",
        description: "Failed to generate variations. Please try again.",
        variant: "destructive",
      })
    }
  }

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast({
        title: "Copied!",
        description: `${text} copied to clipboard`,
      })
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      })
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleGenerate()
    }
  }

  return (
    <>
      <Background />
      <div className="min-h-screen pt-20 px-4">
        <div className="container mx-auto max-w-4xl">
          {/* Input Section */}
          <Card className="mb-8 card-smooth gpu-accelerated rounded-3xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2 text-xl md:text-2xl">
                <Sparkles className="h-5 w-5 md:h-6 md:w-6 text-purple-400" />
                Generate Variations
              </CardTitle>
              <CardDescription className="text-slate-300 text-base md:text-lg">
                Enter your Gmail address to see all possible dot combinations
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <Label htmlFor="email" className="text-slate-200 text-base md:text-lg font-medium">
                  Gmail Address
                </Label>
                {/* Mobile Layout: Input and Button Stacked */}
                <div className="flex flex-col gap-3 md:flex-row md:gap-4">
                  <Input
                    id="email"
                    type="email"
                    placeholder="example@gmail.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="bg-slate-800/60 border-slate-600/50 text-white placeholder:text-slate-400 focus:border-purple-500 focus:ring-purple-500/20 text-base md:text-lg py-4 md:py-6 backdrop-blur-sm rounded-2xl w-full"
                  />
                  <Button
                    onClick={handleGenerate}
                    disabled={isGenerating}
                    className="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white px-6 py-4 md:px-8 md:py-6 text-base md:text-lg font-semibold transition-all duration-300 transform hover:scale-105 rounded-2xl w-full md:w-auto"
                  >
                    {isGenerating ? "Generating..." : "Generate"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Results Section */}
          {variations.length > 0 && (
            <Card className="card-smooth gpu-accelerated rounded-3xl">
              <CardHeader>
                <CardTitle className="text-white text-xl md:text-2xl">
                  Generated Variations ({variations.length})
                </CardTitle>
                <CardDescription className="text-slate-300 text-base md:text-lg">
                  All these email addresses will deliver to the same Gmail inbox
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96 w-full">
                  <div className="grid gap-3">
                    {variations.map((variation, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 md:p-4 bg-slate-800/40 rounded-2xl border border-slate-600/30 hover:bg-slate-700/50 transition-all duration-300 group backdrop-blur-sm"
                      >
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <div className="w-8 h-8 md:w-10 md:h-10 bg-purple-600/20 rounded-full flex items-center justify-center text-xs md:text-sm text-purple-300 font-mono border border-purple-500/20 flex-shrink-0">
                            {index + 1}
                          </div>
                          <span className="text-white font-mono text-sm md:text-base break-all">{variation}</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(variation)}
                          className="opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-all duration-300 text-slate-400 hover:text-white hover:bg-purple-600/20 transform hover:scale-110 rounded-xl flex-shrink-0 ml-2"
                        >
                          <Copy className="h-4 w-4 md:h-5 md:w-5" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          )}

          {/* Info Section */}
          <div className="mt-8 text-center">
            <Card className="card-smooth gpu-accelerated rounded-3xl">
              <CardContent className="pt-6 md:pt-8">
                <p className="text-slate-300 text-base md:text-lg">
                  <strong className="text-white">Did you know?</strong> Gmail ignores dots (periods) in usernames. This
                  means john.doe@gmail.com, johndoe@gmail.com, and j.o.h.n.d.o.e@gmail.com all go to the same inbox!
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  )
}
