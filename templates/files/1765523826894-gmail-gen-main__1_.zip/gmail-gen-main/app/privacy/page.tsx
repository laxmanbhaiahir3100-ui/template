import type { Metadata } from "next"
import { Card, CardContent } from "@/components/ui/card"
import Background from "@/components/background"

export const metadata: Metadata = {
  title: "Privacy Policy - Gmail Gen | Modverse",
  description:
    "Read our Privacy Policy to understand how Gmail Gen protects your data. We process everything locally and never store your information.",
  keywords: "privacy policy, gmail gen privacy, data protection, modverse privacy",
  alternates: {
    canonical: "https://gmailgen.modverse.online/privacy",
  },
}

export default function PrivacyPage() {
  return (
    <>
      <Background />
      <div className="hero">
        <div className="container mx-auto max-w-4xl px-4">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-4">Privacy Policy</h1>
            <p className="text-slate-400 text-lg">Last updated: January 2024</p>
          </div>

          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardContent className="pt-6 space-y-6 text-slate-300">
              <section>
                <h2 className="text-xl font-bold text-white mb-3">1. Information We Collect</h2>
                <p>
                  <strong>Gmail Gen does not collect, store, or transmit any personal information.</strong> All
                  processing happens locally in your browser. We do not have access to:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>Your email addresses</li>
                  <li>Generated variations</li>
                  <li>Any personal data you enter</li>
                  <li>Your browsing patterns on our site</li>
                </ul>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">2. How We Use Information</h2>
                <p>
                  Since we don't collect any personal information, we don't use, share, or sell any personal data. The
                  only data processing that occurs is:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>Local processing of your Gmail address to generate variations</li>
                  <li>Temporary storage in your browser's memory during use</li>
                  <li>No data persists after you close the browser tab</li>
                </ul>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">3. Google Analytics</h2>
                <p>
                  We use Google Analytics to understand how visitors interact with our website. Google Analytics
                  collects:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>Anonymous usage statistics</li>
                  <li>Page views and session duration</li>
                  <li>General geographic location (country/city level)</li>
                  <li>Device and browser information</li>
                </ul>
                <p className="mt-2">
                  This data is anonymized and used solely for improving our service. You can opt-out of Google Analytics
                  by using browser extensions or disabling JavaScript.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">4. Cookies</h2>
                <p>
                  Gmail Gen does not use cookies for tracking or storing personal information. The only cookies present
                  are from Google Analytics, which are used for anonymous analytics purposes only.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">5. Third-Party Services</h2>
                <p>We use the following third-party services:</p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>
                    <strong>Google Analytics:</strong> For anonymous website analytics
                  </li>
                  <li>
                    <strong>Vercel:</strong> For website hosting and delivery
                  </li>
                </ul>
                <p className="mt-2">
                  These services have their own privacy policies and may collect anonymous usage data.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">6. Data Security</h2>
                <p>
                  Since we don't collect or store any personal data, there's no risk of data breaches involving your
                  personal information. All processing happens securely in your browser using standard web technologies.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">7. Children's Privacy</h2>
                <p>
                  Gmail Gen does not knowingly collect any information from children under 13. Since we don't collect
                  personal information from anyone, this service is safe for all age groups.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">8. Changes to Privacy Policy</h2>
                <p>
                  We may update this Privacy Policy from time to time. We will notify you of any changes by posting the
                  new Privacy Policy on this page and updating the "Last updated" date.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">9. Contact Us</h2>
                <p>If you have any questions about this Privacy Policy, please contact us:</p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>Telegram: @lakhan_lakhnot</li>
                  <li>Website: modverse.online</li>
                </ul>
              </section>

              <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-4 mt-6">
                <h3 className="text-green-400 font-bold mb-2">Privacy Guarantee</h3>
                <p className="text-green-300 text-sm">
                  We guarantee that Gmail Gen processes everything locally in your browser. Your email addresses never
                  leave your device, ensuring complete privacy and security.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  )
}
