import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Toaster } from "@/components/ui/toaster"
import Script from "next/script"
import Header from "@/components/header"
import Footer from "@/components/footer"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  metadataBase: new URL("https://gmailgen.modverse.online"),
  title: "Gmail Gen - Free Gmail Dot Variation Generator | Modverse",
  description:
    "Generate unlimited Gmail dot variations instantly. Create multiple email addresses from one Gmail account. Free Gmail generator tool by Modverse.",
  keywords:
    "gmail generator, gmail dot variations, email generator, gmail tricks, multiple gmail addresses, gmail dots, email variations, modverse, modverse.online, tempmail, temp mail, tempmail.modverse, tempmail.modverse.online, gmail gen, gmailgen, gmailgen.modverse, gmailgen.modverse.online, lakhan, lakhan ahir, lakhanahir, lakhan lakhnotra, lakhanlakhnotra, @lakhan, @lakhan ahir, @lakhan_ahir, @lakhan_lakhnotra, @lakhan_ahir_9499, lakhanlakhnotra.online,",
  authors: [{ name: "Modverse", url: "https://modverse.online" }],
  creator: "Modverse",
  publisher: "Modverse",
  robots: "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1",
  openGraph: {
    title: "Gmail Gen - Free Gmail Dot Variation Generator",
    description:
      "Generate unlimited Gmail dot variations instantly. Create multiple email addresses from one Gmail account.",
    url: "https://gmailgen.modverse.online",
    siteName: "Gmail Gen",
    type: "website",
    locale: "en_US",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Gmail Gen - Gmail Dot Variation Generator",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Gmail Gen - Free Gmail Dot Variation Generator",
    description:
      "Generate unlimited Gmail dot variations instantly. Create multiple email addresses from one Gmail account.",
    images: ["/og-image.png"],
    creator: "@modverse",
  },
  alternates: {
    canonical: "https://gmailgen.modverse.online",
  },
  verification: {
    google: "your-google-verification-code",
    other: {
      "msvalidate.01": "your-bing-verification-code",
    },
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        {/* Google Analytics */}
        <Script async src="https://www.googletagmanager.com/gtag/js?id=G-GDMHDMQ0Q7" />
        <Script id="google-analytics">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-GDMHDMQ0Q7');
          `}
        </Script>

        {/* Structured Data */}
        <Script id="structured-data" type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "Gmail Gen",
              "description": "Generate unlimited Gmail dot variations instantly",
              "url": "https://gmailgen.modverse.online",
              "applicationCategory": "UtilityApplication",
              "operatingSystem": "Web Browser",
              "browserRequirements": "Requires JavaScript",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "creator": {
                "@type": "Organization",
                "name": "Modverse",
                "url": "https://modverse.online",
                "sameAs": [
                  "https://t.me/modverse_online"
                ]
              },
              "datePublished": "2024-01-01",
              "dateModified": "${new Date().toISOString()}",
              "inLanguage": "en-US",
              "isAccessibleForFree": true,
              "keywords": "gmail generator, email variations, gmail dots, free tool"
            }
          `}
        </Script>

        {/* Additional SEO Meta Tags */}
        <meta name="theme-color" content="#6c5ce7" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="Gmail Gen" />
        <meta name="application-name" content="Gmail Gen" />
        <meta name="msapplication-TileColor" content="#6c5ce7" />
        <meta name="msapplication-config" content="/browserconfig.xml" />

        {/* Preconnect for Performance */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="preconnect" href="https://www.googletagmanager.com" />

        {/* Favicon */}
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
        <link rel="manifest" href="/site.webmanifest" />
      </head>
      <body className={inter.className}>
        <Header />
        <main className="min-h-screen">{children}</main>
        <Footer />
        <Toaster />
      </body>
    </html>
  )
}
