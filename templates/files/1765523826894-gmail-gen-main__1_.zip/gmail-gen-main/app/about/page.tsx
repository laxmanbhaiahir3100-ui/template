import type { Metadata } from "next"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Mail, Users, Zap, Shield } from "lucide-react"
import Background from "@/components/background"

export const metadata: Metadata = {
  title: "About Gmail Gen - Free Gmail Dot Variation Generator | Modverse",
  description:
    "Learn about Gmail Gen, the free tool to generate Gmail dot variations. Discover how Gmail ignores dots and create unlimited email addresses.",
  keywords: "about gmail gen, gmail dot variations, how gmail works, email generator, modverse",
  alternates: {
    canonical: "https://gmailgen.modverse.online/about",
  },
}

export default function AboutPage() {
  return (
    <>
      <Background />
      <div className="hero">
        <div className="container mx-auto max-w-4xl px-4">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-4">About Gmail Gen</h1>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto">
              Learn how Gmail Gen helps you create unlimited email variations from a single Gmail account
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2">
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Mail className="h-5 w-5 text-purple-400" />
                  What is Gmail Gen?
                </CardTitle>
              </CardHeader>
              <CardContent className="text-slate-300">
                <p>
                  Gmail Gen is a free tool that generates all possible dot variations of your Gmail username. Since
                  Gmail ignores dots in email addresses, you can create multiple variations that all deliver to the same
                  inbox.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Zap className="h-5 w-5 text-purple-400" />
                  How It Works
                </CardTitle>
              </CardHeader>
              <CardContent className="text-slate-300">
                <p>
                  Our algorithm generates all mathematical combinations of dots between letters in your username. For
                  example, "john" becomes "john", "j.ohn", "jo.hn", "j.o.hn", etc. All variations deliver to the same
                  Gmail inbox.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Users className="h-5 w-5 text-purple-400" />
                  Use Cases
                </CardTitle>
              </CardHeader>
              <CardContent className="text-slate-300">
                <ul className="list-disc list-inside space-y-2">
                  <li>Organize emails by using different variations for different services</li>
                  <li>Track which websites sell your email address</li>
                  <li>Create multiple accounts on platforms that allow it</li>
                  <li>Filter emails more effectively</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Shield className="h-5 w-5 text-purple-400" />
                  Privacy & Security
                </CardTitle>
              </CardHeader>
              <CardContent className="text-slate-300">
                <p>
                  Gmail Gen processes everything locally in your browser. We don't store, log, or transmit your email
                  addresses. Your privacy is completely protected, and the tool works entirely offline after loading.
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-8 bg-slate-800/30 border-slate-700/50 backdrop-blur-sm">
            <CardContent className="pt-6 text-center">
              <h2 className="text-2xl font-bold text-white mb-4">Made by Modverse</h2>
              <p className="text-slate-400">
                Gmail Gen is created by{" "}
                <a
                  href="https://modverse.online"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-purple-400 hover:text-purple-300 transition-colors"
                >
                  Modverse
                </a>
                , a platform dedicated to creating useful web tools and applications. We believe in making the internet
                more accessible and productive for everyone.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  )
}
