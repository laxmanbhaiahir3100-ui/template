import type { Metadata } from "next"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MessageCircle, Globe, Users } from "lucide-react"
import Background from "@/components/background"

export const metadata: Metadata = {
  title: "Contact Gmail Gen - Get Support & Feedback | Modverse",
  description:
    "Contact Gmail Gen team for support, feedback, or questions. Reach us via Telegram or visit our website.",
  keywords: "contact gmail gen, support, feedback, telegram, modverse contact",
  alternates: {
    canonical: "https://gmailgen.modverse.online/contact",
  },
}

export default function ContactPage() {
  return (
    <>
      <Background />
      <div className="hero">
        <div className="container mx-auto max-w-4xl px-4">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-4">Contact Us</h1>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto">
              Have questions, feedback, or need support? We'd love to hear from you!
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2">
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <MessageCircle className="h-5 w-5 text-purple-400" />
                  Telegram Support
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-white font-semibold mb-2">Direct Contact</h3>
                  <a
                    href="https://t.me/lakhan_lakhnotra"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-2"
                  >
                    <MessageCircle className="h-4 w-4" />
                    @lakhan_lakhnotra
                  </a>
                  <p className="text-slate-400 text-sm mt-2">
                    Get direct support and quick responses to your questions.
                  </p>
                </div>

                <div>
                  <h3 className="text-white font-semibold mb-2">Official Channel</h3>
                  <a
                    href="https://t.me/modverse_online"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-2"
                  >
                    <Users className="h-4 w-4" />
                    @modverse_online
                  </a>
                  <p className="text-slate-400 text-sm mt-2">Stay updated with latest tools and announcements.</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Globe className="h-5 w-5 text-purple-400" />
                  Website & More Tools
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-white font-semibold mb-2">Modverse Website</h3>
                  <a
                    href="https://modverse.online"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-2"
                  >
                    <Globe className="h-4 w-4" />
                    modverse.online
                  </a>
                  <p className="text-slate-400 text-sm mt-2">
                    Discover more useful tools and applications we've built.
                  </p>
                </div>

                <div>
                  <h3 className="text-white font-semibold mb-2">Business Inquiries</h3>
                  <p className="text-slate-400 text-sm">
                    For business partnerships, collaborations, or custom tool development, please reach out via our
                    Telegram or website.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-8 bg-slate-800/30 border-slate-700/50 backdrop-blur-sm">
            <CardContent className="pt-6">
              <h2 className="text-2xl font-bold text-white mb-4 text-center">Frequently Asked Questions</h2>
              <div className="space-y-4">
                <div>
                  <h3 className="text-white font-semibold mb-2">Is Gmail Gen free to use?</h3>
                  <p className="text-slate-400 text-sm">
                    Yes! Gmail Gen is completely free to use with no limitations or registration required.
                  </p>
                </div>

                <div>
                  <h3 className="text-white font-semibold mb-2">Do you store my email addresses?</h3>
                  <p className="text-slate-400 text-sm">
                    No, we don't store any data. All processing happens locally in your browser for complete privacy.
                  </p>
                </div>

                <div>
                  <h3 className="text-white font-semibold mb-2">Can I suggest new features?</h3>
                  <p className="text-slate-400 text-sm">
                    We welcome feature suggestions and feedback via our Telegram channels.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  )
}
