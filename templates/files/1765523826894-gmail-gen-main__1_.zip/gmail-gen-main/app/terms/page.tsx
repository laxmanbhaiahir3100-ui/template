import type { Metadata } from "next"
import { Card, CardContent } from "@/components/ui/card"
import Background from "@/components/background"

export const metadata: Metadata = {
  title: "Terms of Service - Gmail Gen | Modverse",
  description:
    "Read the Terms of Service for Gmail Gen. Understand your rights and responsibilities when using our Gmail dot variation generator.",
  keywords: "terms of service, gmail gen terms, legal, modverse terms",
  alternates: {
    canonical: "https://gmailgen.modverse.online/terms",
  },
}

export default function TermsPage() {
  return (
    <>
      <Background />
      <div className="hero">
        <div className="container mx-auto max-w-4xl px-4">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-4">Terms of Service</h1>
            <p className="text-slate-400 text-lg">Last updated: January 2024</p>
          </div>

          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardContent className="pt-6 space-y-6 text-slate-300">
              <section>
                <h2 className="text-xl font-bold text-white mb-3">1. Acceptance of Terms</h2>
                <p>
                  By accessing and using Gmail Gen ("the Service"), you accept and agree to be bound by the terms and
                  provision of this agreement. If you do not agree to abide by the above, please do not use this
                  service.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">2. Description of Service</h2>
                <p>
                  Gmail Gen is a free web-based tool that generates dot variations of Gmail usernames. The service
                  operates entirely in your browser and does not store or transmit your email addresses.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">3. Use License</h2>
                <p>
                  Permission is granted to temporarily use Gmail Gen for personal, non-commercial transitory viewing
                  only. This is the grant of a license, not a transfer of title, and under this license you may not:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>modify or copy the materials</li>
                  <li>use the materials for any commercial purpose or for any public display</li>
                  <li>attempt to reverse engineer any software contained on the website</li>
                  <li>remove any copyright or other proprietary notations from the materials</li>
                </ul>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">4. Disclaimer</h2>
                <p>
                  The information on this website is provided on an "as is" basis. To the fullest extent permitted by
                  law, this Company excludes all representations, warranties, conditions and terms whether express or
                  implied.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">5. Privacy</h2>
                <p>
                  Gmail Gen processes all data locally in your browser. We do not collect, store, or transmit any
                  personal information or email addresses. For more details, please refer to our Privacy Policy.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">6. Limitations</h2>
                <p>
                  In no event shall Modverse or its suppliers be liable for any damages (including, without limitation,
                  damages for loss of data or profit, or due to business interruption) arising out of the use or
                  inability to use Gmail Gen.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">7. Accuracy of Materials</h2>
                <p>
                  The materials appearing on Gmail Gen could include technical, typographical, or photographic errors.
                  Modverse does not warrant that any of the materials on its website are accurate, complete, or current.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">8. Modifications</h2>
                <p>
                  Modverse may revise these terms of service at any time without notice. By using this website, you are
                  agreeing to be bound by the then current version of these terms of service.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-3">9. Contact Information</h2>
                <p>If you have any questions about these Terms of Service, please contact us via:</p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>Telegram: @lakhan_lakhnot</li>
                  <li>Website: modverse.online</li>
                </ul>
              </section>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  )
}
