"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { Github, Send, MapPin, Clock, Star, Bot, Code } from "lucide-react"

export default function ProfilePage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="profile-container">
      <div className="animated-bg">
        <div className="gradient-orb orb-1"></div>
        <div className="gradient-orb orb-2"></div>
        <div className="gradient-orb orb-3"></div>
        <div className="floating-particles">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="particle"
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${3 + Math.random() * 4}s`,
              }}
            ></div>
          ))}
        </div>
      </div>

      <div className="profile-content">
        <div className="profile-header">
          <div className="profile-image-container">
            <Image
              src="/profile-avatar.jpeg"
              alt="LAKHAN Profile Picture"
              width={150}
              height={150}
              className="profile-image"
              priority // Ensure high priority for LCP
            />
            <div className="profile-ring"></div>
          </div>
          <h1 className="profile-name">LAKHAN</h1>
          <p className="profile-tagline">Software Developer | Ethical Hacker | Digital Creator</p>
          <div className="location-info">
            <div className="location-item">
              <MapPin size={16} />
              <span>India, Gujarat</span>
            </div>
          </div>
        </div>

        <div className="social-section">
          <a
            href="https://t.me/Lakhan_Lakhnotra"
            target="_blank"
            rel="noopener noreferrer"
            className="social-link telegram"
          >
            <Send size={20} />
            <span>Telegram</span>
          </a>
          <a href="https://github.com/" target="_blank" rel="noopener noreferrer" className="social-link github">
            <Github size={20} />
            <span>GitHub</span>
          </a>
        </div>

        <div className="info-grid">
          <div className="info-card skills">
            <div className="card-header">
              <Star className="card-icon" size={20} />
              <h3>Skills & Expertise</h3>
            </div>
            <ul className="skills-list">
              <li>Ethical Hacking</li>
              <li>Web Development (Full-Stack)</li>
              <li>Telegram Bots Development</li>
              <li>System Administration</li>
              <li>Digital Marketing</li>
            </ul>
          </div>

          <div className="info-card online-time">
            <div className="card-header">
              <Clock className="card-icon" size={20} />
              <h3>Online Time</h3>
            </div>
            <p>6 PM To 12 AM (IST)</p>
          </div>

          <div className="info-card admin-groups">
            <div className="card-header">
              <Send className="card-icon" size={20} />
              <h3>Admin On</h3>
            </div>
            <div className="links-list">
              <a href="https://t.me/modverse_online" target="_blank" rel="noopener noreferrer">
                Modverse
              </a>
              <a href="https://t.me/bgmi_ddos_group" target="_blank" rel="noopener noreferrer">
                Bgmi Ddos
              </a>
            </div>
          </div>

          <div className="info-card channel">
            <div className="card-header">
              <Send className="card-icon" size={20} />
              <h3>Own Channel</h3>
            </div>
            <a href="https://t.me/modverse_online" target="_blank" rel="noopener noreferrer">
              MODVERSE
            </a>
          </div>

          <div className="info-card bots">
            <div className="card-header">
              <Bot className="card-icon" size={20} />
              <h3>Our Bots</h3>
            </div>
            <div className="links-list">
              <a href="https://t.me/Temp_mail_free_robot" target="_blank" rel="noopener noreferrer">
                Temp Mail Bot
              </a>
              <a href="https://t.me/Refer_andearnrobot" target="_blank" rel="noopener noreferrer">
                Refer & Earn Bot
              </a>
            </div>
          </div>

          <div className="info-card projects">
            <div className="card-header">
              <Code className="card-icon" size={20} />
              <h3>My Projects </h3>
            </div>
            <div className="websites-grid">
              <a href="https://panel.modverse.online/" target="_blank" rel="noopener noreferrer">
                panel.modverse.online
              </a>
              <a href="https://moviehub.modverse.online/" target="_blank" rel="noopener noreferrer">
                moviehub.modverse.online
              </a>
              <a href="https://scraper.modverse.online/" target="_blank" rel="noopener noreferrer">
                scraper.modverse.online
              </a>
              <a href="https://vscode.modverse.online/" target="_blank" rel="noopener noreferrer">
                vscode.modverse.online
              </a>
              <a href="https://gmailgen.modverse.online/" target="_blank" rel="noopener noreferrer">
                gmailgen.modverse.online
              </a>
              <a href="https://modverse.modverse.online/" target="_blank" rel="noopener noreferrer">
                modverse.modverse.online
              </a>
              <a href="https://tempmail.modverse.online/" target="_blank" rel="noopener noreferrer">
                tempmail.modverse.online
              </a>
              <a href="https://tm.modverse.online/" target="_blank" rel="noopener noreferrer">
                tm.modverse.online
              </a>
              <a href="https://lakhanlakhnotra.online/" target="_blank" rel="noopener noreferrer">
                lakhanlakhnotra.online
              </a>
            </div>
          </div>
        </div>

        <a href="https://t.me/Lakhan_Lakhnotra" target="_blank" rel="noopener noreferrer" className="contact-button">
          <Send size={20} />
          <span>Contact Me</span>
          <div className="button-glow"></div>
        </a>
      </div>
    </div>
  )
}
