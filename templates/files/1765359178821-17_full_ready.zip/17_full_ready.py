#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Modified per user request:
- Grant subscription & Add admin & Edit active search: manual ID entry only (no select).
- View admins shows username too.
- List users removed.
- Download users TXT moved to User Management.
- Total users moved to User Management.
- Broadcast moved to Admin Panel main menu.
- System Tools page/button removed.
"""
import re
import sqlite3
import requests
import traceback
import os
import tempfile
from datetime import datetime, date, timedelta
from functools import wraps
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

# ---------------- CONFIG ----------------
BOT_TOKEN = "8474101174:AAET78ng6un0MVnczLPUfiFJEV94kGyg6Nc"
ADMIN_ID = 1386134836  # main admin (protected)
API_KEY = "VehicleInfoX"
NUMBER_API_URL = "https://voidzero-api.koyeb.app/api/phonenumber?number={number}&key={key}"
DB_PATH = "number_info_bot.db"
FREE_DAILY_LIMIT = 2
API_ID = 24627174
API_HASH = "0590457d36e07e903704daa3b99fb846"
LOG_BUFFER_SIZE = 500
# ----------------------------------------

app = Client("numinfo_bot_v9", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

# ---------------- DB setup ----------------
conn = sqlite3.connect(DB_PATH, check_same_thread=False)
cur = conn.cursor()

cur.execute("""CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    registered_at TEXT,
    premium_searches INTEGER DEFAULT 0,
    total_searches INTEGER DEFAULT 0,
    last_reset TEXT,
    subscription_until TEXT
)""")

cur.execute("""CREATE TABLE IF NOT EXISTS daily_usage (
    user_id INTEGER PRIMARY KEY,
    date TEXT,
    used INTEGER DEFAULT 0
)""")

cur.execute("""CREATE TABLE IF NOT EXISTS redeem_codes (
    code TEXT PRIMARY KEY,
    max_uses INTEGER,
    uses INTEGER DEFAULT 0,
    reward INTEGER,
    created_by INTEGER,
    created_at TEXT
)""")

cur.execute("""CREATE TABLE IF NOT EXISTS redeem_uses (
    code TEXT,
    user_id INTEGER,
    used_at TEXT,
    PRIMARY KEY (code, user_id)
)""")

cur.execute("""CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY)""")

cur.execute("""CREATE TABLE IF NOT EXISTS user_states (
    user_id INTEGER PRIMARY KEY,
    awaiting_search INTEGER DEFAULT 0,
    state TEXT DEFAULT '',
    state_data TEXT DEFAULT ''
)""")

conn.commit()
cur.execute("INSERT OR IGNORE INTO admins (id) VALUES (?)", (ADMIN_ID,))
conn.commit()

# ---------------- Logging buffer ----------------
LOGS = []

def append_log(line: str):
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    entry = f"[{ts}] {line}"
    LOGS.append(entry)
    if len(LOGS) > LOG_BUFFER_SIZE:
        del LOGS[0: len(LOGS) - LOG_BUFFER_SIZE]

def log(s):
    append_log(s)

# ---------------- Helpers ----------------
def ensure_user(user):
    uid = user.id
    cur.execute("SELECT id FROM users WHERE id=?", (uid,))
    if not cur.fetchone():
        cur.execute("INSERT INTO users (id, username, first_name, registered_at, last_reset) VALUES (?, ?, ?, ?, ?)",
                    (uid, user.username or "", user.first_name or "", datetime.utcnow().isoformat(), date.today().isoformat()))
        cur.execute("INSERT OR IGNORE INTO daily_usage (user_id, date, used) VALUES (?, ?, 0)", (uid, date.today().isoformat()))
        cur.execute("INSERT OR IGNORE INTO user_states (user_id, awaiting_search, state, state_data) VALUES (?, 0, '', '')", (uid,))
        conn.commit()
        log(f"New user added: {uid}")
    return uid

def is_admin(uid):
    cur.execute("SELECT 1 FROM admins WHERE id=?", (uid,))
    return bool(cur.fetchone())

def admin_only(fn):
    @wraps(fn)
    def wrapper(client, message, *a, **kw):
        uid = message.from_user.id
        if not is_admin(uid):
            message.reply_text("❌ Access Denied. Admins only.")
            return
        return fn(client, message, *a, **kw)
    return wrapper

def reset_daily(uid):
    today = date.today().isoformat()
    cur.execute("SELECT date FROM daily_usage WHERE user_id=?", (uid,))
    r = cur.fetchone()
    if not r or r[0] != today:
        cur.execute("INSERT OR REPLACE INTO daily_usage (user_id, date, used) VALUES (?, ?, 0)", (uid, today))
        conn.commit()

def get_daily_used(uid):
    reset_daily(uid)
    cur.execute("SELECT used FROM daily_usage WHERE user_id=?", (uid,))
    r = cur.fetchone()
    return r[0] if r else 0

def increment_usage(uid):
    reset_daily(uid)
    cur.execute("UPDATE daily_usage SET used=used+1 WHERE user_id=?", (uid,))
    cur.execute("UPDATE users SET total_searches=total_searches+1 WHERE id=?", (uid,))
    conn.commit()

def set_state(uid, state, data=""):
    cur.execute("INSERT OR REPLACE INTO user_states (user_id, awaiting_search, state, state_data) VALUES (?, COALESCE((SELECT awaiting_search FROM user_states WHERE user_id=?),0), ?, ?)",
                (uid, uid, state, data))
    conn.commit()
    log(f"State set for {uid}: {state} | data: {data}")

def clear_state(uid):
    cur.execute("UPDATE user_states SET awaiting_search=0, state='', state_data='' WHERE user_id=?", (uid,))
    conn.commit()
    log(f"State cleared for {uid}")

def get_state(uid):
    cur.execute("SELECT awaiting_search, state, state_data FROM user_states WHERE user_id=?", (uid,))
    r = cur.fetchone()
    if not r:
        cur.execute("INSERT INTO user_states (user_id, awaiting_search, state, state_data) VALUES (?, 0, '', '')", (uid,))
        conn.commit()
        return (0, "", "")
    return r

# ---------------- Keyboards ----------------
def main_menu(is_admin=False):
    kb = [
        [InlineKeyboardButton("🔎 Search Number", callback_data="cb_search")],
        [InlineKeyboardButton("📊 My Stats", callback_data="cb_stats"),
         InlineKeyboardButton("📅 My Subscription", callback_data="cb_mysub")],
        [InlineKeyboardButton("🎁 Redeem Code", callback_data="cb_redeem"),
         InlineKeyboardButton("❓ Help", callback_data="cb_help")]
    ]
    if is_admin:
        kb.append([InlineKeyboardButton("🛠 Admin Panel", callback_data="cb_admin_main")])
    return InlineKeyboardMarkup(kb)

def admin_main_kb():
    # Added Broadcast here (moved from system tools)
    kb = [
        [InlineKeyboardButton("👥 User Management", callback_data="cb_admin_page_users")],
        [InlineKeyboardButton("🎫 Codes & Promo", callback_data="cb_admin_page_codes"),
         InlineKeyboardButton("📣 Broadcast", callback_data="cb_admin_bcast")],
        [InlineKeyboardButton("🔙 Back to Main", callback_data="cb_back_main")]
    ]
    return InlineKeyboardMarkup(kb)

def admin_users_kb():
    # Modified: removed List Users; added Download Users TXT and Total Users here.
    kb = [
        [InlineKeyboardButton("➕ Grant Subscription", callback_data="cb_admin_grantsub")],
        [InlineKeyboardButton("➕ Add Admin", callback_data="cb_admin_addadmin"),
         InlineKeyboardButton("🗑 Remove Admin", callback_data="cb_admin_removeadmin")],
        [InlineKeyboardButton("👑 View Admins", callback_data="cb_admin_viewadmins"),
         InlineKeyboardButton("📥 Download Users TXT", callback_data="cb_admin_download_users")],
        [InlineKeyboardButton("🔢 Total Users", callback_data="cb_admin_totalusers"),
         InlineKeyboardButton("✂️ Remove Subscription", callback_data="cb_admin_removesub")],
        [InlineKeyboardButton("✏️ Edit Active Search", callback_data="cb_admin_editsearch")],
        [InlineKeyboardButton("🔙 Back", callback_data="cb_admin_main")]
    ]
    return InlineKeyboardMarkup(kb)

def admin_codes_kb():
    kb = [
        [InlineKeyboardButton("🎫 Generate Redeem", callback_data="cb_admin_genredeem"),
         InlineKeyboardButton("📋 List Redeems (all)", callback_data="cb_admin_listcodes")],
        [InlineKeyboardButton("✅ Active Codes", callback_data="cb_admin_list_activecodes"),
         InlineKeyboardButton("🔙 Back", callback_data="cb_admin_main")]
    ]
    return InlineKeyboardMarkup(kb)

def back_kb_to_main():
    return InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="cb_back_main")]])

def back_kb_to_admin():
    return InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="cb_admin_main")]])

# ---------------- Utilities ----------------
def split_and_send_text(chat_id, text, parse_mode="HTML"):
    max_len = 4000
    sent = 0
    try:
        if len(text) <= max_len:
            app.send_message(chat_id, text, parse_mode=parse_mode)
            return 1
        lines = text.splitlines(keepends=True)
        chunk = ""
        for ln in lines:
            if len(chunk) + len(ln) > max_len:
                app.send_message(chat_id, chunk, parse_mode=parse_mode)
                sent += 1
                chunk = ln
            else:
                chunk += ln
        if chunk:
            app.send_message(chat_id, chunk, parse_mode=parse_mode)
            sent += 1
    except Exception as e:
        log(f"split_and_send_text error to {chat_id}: {e}")
    return sent

# ---------------- Safe edit helper ----------------
def safe_edit_or_reply(message_obj, text, reply_markup=None, parse_mode=None):
    try:
        if hasattr(message_obj, "edit_text"):
            message_obj.edit_text(text, reply_markup=reply_markup, parse_mode=parse_mode)
            return
    except Exception as e:
        log(f"[safe_edit] edit failed: {e}")
    try:
        if hasattr(message_obj, "reply_text"):
            message_obj.reply_text(text, reply_markup=reply_markup, parse_mode=parse_mode)
        else:
            chat = getattr(message_obj, "chat", None)
            if chat:
                chat_id = chat.id if hasattr(chat, "id") else chat
                app.send_message(chat_id, text, reply_markup=reply_markup, parse_mode=parse_mode)
    except Exception as e:
        log(f"[safe_edit] fallback reply failed: {e}")

# ---------------- Start ----------------
@app.on_message(filters.command("start"))
def start_cmd(client, message):
    try:
        uid = ensure_user(message.from_user)
        cur.execute("SELECT premium_searches, subscription_until FROM users WHERE id=?", (uid,))
        r = cur.fetchone()
        premium = r[0] if r else 0
        sub_until = r[1] if r else None
        sub_text = "Unlimited" if sub_until and datetime.fromisoformat(sub_until) > datetime.utcnow() else str(premium)
        daily_used = get_daily_used(uid)
        daily_left = max(0, FREE_DAILY_LIMIT - daily_used)
        total = "Unlimited" if sub_text == "Unlimited" else daily_left + premium
        admin_flag = is_admin(uid)
        welcome_block = (
            "» ᴡᴇʟᴄᴏᴍᴇ ᴛᴏ ɴᴜᴍʙᴇʀ ɪɴғᴏ ʙᴏᴛ\n\n"
            "🔍 sᴇᴀʀᴄʜ ᴅᴇᴛᴀɪʟs ᴏғ ᴀɴʏ ᴍᴏʙɪʟᴇ ɴᴜᴍʙᴇʀ ᴇᴀsɪʟʏ\n\n"
            "⚠️ ᴛʜɪs ʙᴏᴛ ɪs ᴏɴʟʏ ғᴏʀ ᴇᴅᴜᴄᴀᴛɪᴏɴᴀʟ ᴘᴜʀᴘᴏsᴇs ❌\n\n"
        )

        text = (f"{welcome_block}"
f"👋 Welcome {message.from_user.first_name or 'User'}!\n\n"
                f"📅 Daily left: {daily_left}/{FREE_DAILY_LIMIT}\n"
                f"💎 Premium: {premium}\n"
                f"🚀 Total Available: {total}\n\n"
                "Use buttons below or type /help to see commands.")
        message.reply_text(text, reply_markup=main_menu(admin_flag))
        log(f"/start pressed by {uid}")
    except Exception as e:
        log("Error in /start: " + str(e))
        traceback.print_exc()
        message.reply_text("An error occurred. Check bot logs.")

# ---------------- Callback Query Handler ----------------
@app.on_callback_query()
def cb_handler(client, cq):
    try:
        uid = cq.from_user.id
        ensure_user(cq.from_user)
        data = cq.data or ""
        log(f"Callback from {uid}: {data}")

        # ---------- Main user features ----------
        if data == "cb_search":
            cur.execute("UPDATE user_states SET awaiting_search=1, state='search', state_data='' WHERE user_id=?", (uid,))
            conn.commit()
            safe_edit_or_reply(cq.message, "📞 Send phone number (6-15 digits) now, or use /num <number>.", reply_markup=back_kb_to_main())
            cq.answer()
            return

        if data == "cb_stats":
            reset_daily(uid)
            used = get_daily_used(uid)
            cur.execute("SELECT premium_searches, total_searches, registered_at FROM users WHERE id=?", (uid,))
            rr = cur.fetchone() or (0,0,'N/A')
            p, t, reg = rr[0], rr[1], rr[2]
            join_date = reg.split('T')[0] if reg else 'Unknown'
            txt = f"📊 Stats:
• Daily used: {used}/{FREE_DAILY_LIMIT}
• Premium: {p}
• Total searches: {t}
📅 ᴊᴏɪɴᴇᴅ: {join_date}

💡 ᴛɪᴘ: ʀᴇғᴇʀ ғʀɪᴇɴᴅs ᴛᴏ ɢᴇᴛ ᴍᴏʀᴇ sᴇᴀʀᴄʜᴇs!"
            safe_edit_or_reply(cq.message, txt, reply_markup=back_kb_to_main())
            cq.answer()
            return

        if data == "cb_mysub":
            cur.execute("SELECT subscription_until FROM users WHERE id=?", (uid,))
            r = cur.fetchone()
            if not r or not r[0]:
                safe_edit_or_reply(cq.message, "📅 No active subscription.", reply_markup=back_kb_to_main())
            else:
                end = datetime.fromisoformat(r[0])
                if end > datetime.utcnow():
                    safe_edit_or_reply(cq.message, f"💎 Active subscription until: {end.strftime('%Y-%m-%d %H:%M UTC')}", reply_markup=back_kb_to_main())
                else:
                    safe_edit_or_reply(cq.message, "❌ Subscription expired.", reply_markup=back_kb_to_main())
            cq.answer()
            return

        if data == "cb_redeem":
            set_state(uid, "await_redeem", "")
            safe_edit_or_reply(cq.message, "🎫 Send redeem code now (or use /redeem <CODE>):", reply_markup=back_kb_to_main())
            cq.answer()
            return

        if data == "cb_help":
            if is_admin(uid):
                text = (
                    "🛠️ Admin Commands (buttons + text):\n"
                    "/start, /help, /num <number>, /redeem <code>, /cancel\n\n"
                    "Admin text commands:\n"
                    "/addadmin <id>, /removeadmin <id>, /admins\n"
                    "/genredeem <code> <max_uses> <reward>, /grantsub <user_id> <days>, /removesub <user_id>\n"
                    "/editsearch <user_id> <count>\n"
                    "/bcast <message>, /totalusers, /downloadusers\n\n"
                    "Use the Admin Panel for button-driven management."
                )
            else:
                text = (
                    "🤖 User Commands:\n"
                    "/start, /help, /num <number>, /redeem <code>, /cancel\n\n"
                    "Use main menu buttons for quick actions."
                )
            safe_edit_or_reply(cq.message, text, reply_markup=back_kb_to_main())
            cq.answer()
            return

        # ---------- Admin panel entry ----------
        if data == "cb_admin_main":
            if not is_admin(uid):
                safe_edit_or_reply(cq.message, "❌ Access Denied. Admins only.", reply_markup=back_kb_to_main())
                cq.answer()
                return
            safe_edit_or_reply(cq.message, "🛠 Admin Panel — Pick a section:", reply_markup=admin_main_kb())
            cq.answer()
            return

        # ---------- Admin: navigate pages ----------
        if data == "cb_admin_page_users":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            safe_edit_or_reply(cq.message, "👥 User Management — choose action:", reply_markup=admin_users_kb())
            cq.answer()
            return

        if data == "cb_admin_page_codes":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            safe_edit_or_reply(cq.message, "🎫 Codes & Promo — choose action:", reply_markup=admin_codes_kb())
            cq.answer()
            return

        # ---------- Admin: Add Admin (manual only) ----------
        if data == "cb_admin_addadmin":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            set_state(uid, "admin_addadmin", "")
            safe_edit_or_reply(cq.message, "✏️ Send: <user_id>\nExample: `123456789`", reply_markup=back_kb_to_admin())
            cq.answer()
            return

        # ---------- Admin: Remove Admin (show list) ----------
        if data == "cb_admin_removeadmin":
            if uid != ADMIN_ID:
                safe_edit_or_reply(cq.message, "❌ Only the main admin can remove admins.", reply_markup=admin_users_kb())
                cq.answer()
                return
            cur.execute("SELECT id FROM admins")
            rows = [r[0] for r in cur.fetchall()]
            removable = [a for a in rows if a != ADMIN_ID]
            if not removable:
                safe_edit_or_reply(cq.message, "No removable admins found (main admin protected).", reply_markup=admin_users_kb())
                cq.answer()
                return
            kb = []
            for a in removable:
                cur.execute("SELECT username, first_name FROM users WHERE id=?", (a,))
                u = cur.fetchone()
                if u:
                    uname = u[0] or ""
                    fname = u[1] or ""
                    label = f"{a}"
                    if uname:
                        label += f" (@{uname})"
                    elif fname:
                        label += f" ({fname})"
                else:
                    label = str(a)
                kb.append([InlineKeyboardButton(f"Remove {label}", callback_data=f"cb_admin_remove:{a}")])
            kb.append([InlineKeyboardButton("🔙 Back", callback_data="cb_admin_page_users")])
            safe_edit_or_reply(cq.message, "🗑 Select an admin to remove (main admin protected):", reply_markup=InlineKeyboardMarkup(kb))
            cq.answer()
            return

        if data and data.startswith("cb_admin_remove:"):
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            if uid != ADMIN_ID:
                safe_edit_or_reply(cq.message, "❌ Only the main admin can remove admins.", reply_markup=admin_users_kb())
                cq.answer()
                return
            try:
                target = int(data.split(":",1)[1])
            except:
                safe_edit_or_reply(cq.message, "Invalid admin id.", reply_markup=admin_users_kb())
                cq.answer()
                return
            if target == ADMIN_ID:
                safe_edit_or_reply(cq.message, "❌ Cannot remove the main admin.", reply_markup=admin_users_kb())
                cq.answer()
                return
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Confirm Remove", callback_data=f"cb_admin_remove_confirm:{target}"),
                 InlineKeyboardButton("❌ Cancel", callback_data="cb_admin_page_users")]
            ])
            safe_edit_or_reply(cq.message, f"⚠️ Confirm removal of admin {target}?", reply_markup=kb)
            cq.answer()
            return

        if data and data.startswith("cb_admin_remove_confirm:"):
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            if uid != ADMIN_ID:
                safe_edit_or_reply(cq.message, "❌ Only the main admin can remove admins.", reply_markup=admin_users_kb())
                cq.answer()
                return
            try:
                target = int(data.split(":",1)[1])
            except:
                safe_edit_or_reply(cq.message, "Invalid admin id.", reply_markup=admin_users_kb())
                cq.answer()
                return
            if target == ADMIN_ID:
                safe_edit_or_reply(cq.message, "❌ Cannot remove the main admin.", reply_markup=admin_users_kb())
                cq.answer()
                return
            cur.execute("DELETE FROM admins WHERE id=?", (target,))
            conn.commit()
            safe_edit_or_reply(cq.message, f"✅ Admin removed: {target}", reply_markup=admin_users_kb())
            log(f"Admin {target} removed by {uid}")
            try:
                app.send_message(target, f"⚠️ You have been removed as admin by {uid}.")
            except:
                pass
            cq.answer()
            return

        # ---------- Admin: View Admins (show username if available) ----------
        if data == "cb_admin_viewadmins":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            cur.execute("SELECT id FROM admins")
            rows = cur.fetchall()
            if not rows:
                safe_edit_or_reply(cq.message, "No admins found.", reply_markup=admin_users_kb())
            else:
                lines = []
                for r in rows:
                    a_id = r[0]
                    cur.execute("SELECT username, first_name FROM users WHERE id=?", (a_id,))
                    u = cur.fetchone()
                    if u:
                        uname = u[0] or ""
                        fname = u[1] or ""
                        label = f"{a_id}"
                        if uname:
                            label += f" (@{uname})"
                        elif fname:
                            label += f" ({fname})"
                    else:
                        label = str(a_id)
                    lines.append(label)
                safe_edit_or_reply(cq.message, "👑 Admins:\n" + "\n".join(lines), reply_markup=admin_users_kb())
            cq.answer()
            return

        # ---------- Admin: Download users TXT (moved into User Management) ----------
        if data == "cb_admin_download_users":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            cur.execute("SELECT id, username, first_name, registered_at, premium_searches, subscription_until, total_searches FROM users ORDER BY id ASC")
            rows = cur.fetchall()
            if not rows:
                safe_edit_or_reply(cq.message, "No users to export.", reply_markup=admin_users_kb())
                cq.answer()
                return
            try:
                tmp = tempfile.NamedTemporaryFile(delete=False, mode="w", encoding="utf-8", suffix=".txt", prefix="users_export_")
                path = tmp.name
                for r in rows:
                    uid_r = r[0]
                    username = r[1] or "-"
                    first_name = r[2] or "-"
                    reg = r[3] or "-"
                    premium = r[4] or 0
                    sub = r[5] or "None"
                    total_s = r[6] or 0
                    line = f"{uid_r} | @{username} | {first_name} | registered:{reg} | premium:{premium} | subscription:{sub} | total:{total_s}\n"
                    tmp.write(line)
                tmp.flush()
                tmp.close()
            except Exception as e:
                log(f"Failed to create temp file: {e}")
                safe_edit_or_reply(cq.message, "❌ Failed to create export file.", reply_markup=admin_users_kb())
                cq.answer()
                return
            try:
                app.send_document(cq.from_user.id, path, caption=f"Users export ({len(rows)} rows).")
                safe_edit_or_reply(cq.message, "✅ Users TXT sent.", reply_markup=admin_users_kb())
                log(f"Users TXT exported and sent to {cq.from_user.id}, path={path}")
            except Exception as e:
                log(f"Failed to send TXT to {cq.from_user.id}: {e}")
                safe_edit_or_reply(cq.message, "❌ Failed to send TXT.", reply_markup=admin_users_kb())
            finally:
                try:
                    if os.path.exists(path):
                        os.remove(path)
                except Exception as e:
                    log(f"Failed to remove temp file {path}: {e}")
            cq.answer()
            return

        # ---------- Admin: Generate Redeem ----------
        if data == "cb_admin_genredeem":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            set_state(uid, "admin_genredeem", "")
            safe_edit_or_reply(cq.message, "🎫 Send: <CODE> <max_uses> <reward>\nExample: `FREE100 100 5`\nOr use /genredeem <code> <max_uses> <reward>.", reply_markup=admin_codes_kb())
            cq.answer()
            return

        if data == "cb_admin_listcodes":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            cur.execute("SELECT code, max_uses, uses, reward, created_by, created_at FROM redeem_codes ORDER BY created_at DESC LIMIT 200")
            rows = cur.fetchall()
            if not rows:
                safe_edit_or_reply(cq.message, "No redeem codes found.", reply_markup=admin_codes_kb())
                cq.answer()
                return
            out = []
            kb = []
            for r in rows:
                out.append(f"{r[0]} | uses: {r[2]}/{r[1]} | reward:{r[3]} | by:{r[4] or '-'}")
                kb.append([InlineKeyboardButton(f"Delete {r[0]}", callback_data=f"cb_admin_deletecode:{r[0]}")])
            txt = "🎫 Redeem codes (all):\n" + "\n".join(out)
            safe_edit_or_reply(cq.message, txt, reply_markup=InlineKeyboardMarkup(kb + [[InlineKeyboardButton("🔙 Back", callback_data="cb_admin_page_codes")]]))
            cq.answer()
            return

        # ---------- Admin: List Active Codes ----------
        if data == "cb_admin_list_activecodes":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            cur.execute("SELECT code, max_uses, uses, reward, created_by, created_at FROM redeem_codes WHERE uses < max_uses ORDER BY created_at DESC")
            rows = cur.fetchall()
            if not rows:
                safe_edit_or_reply(cq.message, "No active redeem codes found.", reply_markup=admin_codes_kb())
                cq.answer()
                return
            out = []
            kb = []
            for r in rows:
                remaining = r[1] - r[2]
                out.append(f"{r[0]} | remaining: {remaining}/{r[1]} | reward:{r[3]} | by:{r[4] or '-'}")
                kb.append([InlineKeyboardButton(f"Delete {r[0]}", callback_data=f"cb_admin_deletecode:{r[0]}")])
            txt = "✅ Active redeem codes:\n" + "\n".join(out)
            safe_edit_or_reply(cq.message, txt, reply_markup=InlineKeyboardMarkup(kb + [[InlineKeyboardButton("🔙 Back", callback_data="cb_admin_page_codes")]]))
            cq.answer()
            return

        # ---------- Admin: Delete Redeem Code ----------
        if data and data.startswith("cb_admin_deletecode:"):
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            code = data.split(":",1)[1]
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Confirm Delete", callback_data=f"cb_admin_deletecode_confirm:{code}"),
                 InlineKeyboardButton("❌ Cancel", callback_data="cb_admin_page_codes")]
            ])
            safe_edit_or_reply(cq.message, f"⚠️ Confirm delete redeem code: {code} ?", reply_markup=kb)
            cq.answer()
            return

        if data and data.startswith("cb_admin_deletecode_confirm:"):
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            code = data.split(":",1)[1]
            cur.execute("DELETE FROM redeem_codes WHERE code=?", (code,))
            cur.execute("DELETE FROM redeem_uses WHERE code=?", (code,))
            conn.commit()
            safe_edit_or_reply(cq.message, f"✅ Redeem code deleted: {code}", reply_markup=admin_codes_kb())
            log(f"Redeem code deleted by {uid}: {code}")
            cq.answer()
            return

        # ---------- Admin: Broadcast (now accessible from admin main) ----------
        if data == "cb_admin_bcast":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            set_state(uid, "admin_bcast", "")
            safe_edit_or_reply(cq.message, "📣 Send the message to broadcast to all users (or use /bcast <message>):", reply_markup=admin_main_kb())
            cq.answer()
            return

        # ---------- Admin: Total users (moved to user management) ----------
        if data == "cb_admin_totalusers":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            cur.execute("SELECT COUNT(*) FROM users")
            total = cur.fetchone()[0]
            safe_edit_or_reply(cq.message, f"🔢 Total users: {total}", reply_markup=admin_users_kb())
            cq.answer()
            return

        # ---------- Admin: Grant Subscription (manual only) ----------
        if data == "cb_admin_grantsub":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            set_state(uid, "admin_grantsub", "")
            safe_edit_or_reply(cq.message, "➕ Send: <user_id> <days>\nExample: `123456789 30`", reply_markup=back_kb_to_admin())
            cq.answer()
            return

        # ---------- Admin: Remove Subscription flow (only active subs shown) ----------
        if data == "cb_admin_removesub":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            cur.execute("SELECT id, username FROM users WHERE subscription_until IS NOT NULL AND subscription_until > ? ORDER BY subscription_until DESC LIMIT 20", (datetime.utcnow().isoformat(),))
            rows = cur.fetchall()
            if not rows:
                safe_edit_or_reply(cq.message, "No users with active subscriptions found.", reply_markup=admin_users_kb())
                cq.answer()
                return
            kb = []
            for r in rows:
                label = f"{r[0]}"
                if r[1]:
                    label += f" (@{r[1]})"
                kb.append([InlineKeyboardButton(label, callback_data=f"cb_admin_removesub_user:{r[0]}")])
            kb.append([InlineKeyboardButton("✏️ Enter ID manually", callback_data="cb_admin_removesub_manual")])
            kb.append([InlineKeyboardButton("🔙 Back", callback_data="cb_admin_page_users")])
            safe_edit_or_reply(cq.message, "✂️ Remove subscription — choose user or manual entry:", reply_markup=InlineKeyboardMarkup(kb))
            cq.answer()
            return

        if data and data.startswith("cb_admin_removesub_user:"):
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            target = int(data.split(":",1)[1])
            cur.execute("UPDATE users SET subscription_until=NULL WHERE id=?", (target,))
            conn.commit()
            safe_edit_or_reply(cq.message, f"✅ Subscription removed for {target}.", reply_markup=admin_users_kb())
            try:
                app.send_message(target, f"⚠️ Your subscription has been removed by admin {uid}.")
            except:
                pass
            log(f"Subscription removed for {target} by {uid}")
            cq.answer()
            return

        if data == "cb_admin_removesub_manual":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            set_state(uid, "admin_removesub", "")
            safe_edit_or_reply(cq.message, "✂️ Send: <user_id>\nExample: `123456789`", reply_markup=back_kb_to_admin())
            cq.answer()
            return

        # ---------- Admin: Edit Active Search (manual only) ----------
        if data == "cb_admin_editsearch":
            if not is_admin(uid):
                cq.answer("Access denied.")
                return
            set_state(uid, "admin_editsearch", "")
            safe_edit_or_reply(cq.message, "✏️ Send: <user_id> <count>\nExample: `123456789 10`", reply_markup=back_kb_to_admin())
            cq.answer()
            return

        # ---------- Back to main menu ----------
        if data == "cb_back_main":
            admin_flag = is_admin(uid)
            safe_edit_or_reply(cq.message, "🔙 Returning to main menu.", reply_markup=main_menu(admin_flag))
            clear_state(uid)
            cq.answer()
            return

        cq.answer()
    except Exception as e:
        log("Callback handler error: " + str(e))
        traceback.print_exc()
        try:
            cq.answer("An error occurred.")
        except:
            pass

# ---------------- Text handler: states & search ----------------
@app.on_message(filters.text & ~filters.command([
    "start","num","cancel","redeem","addadmin","removeadmin","admins",
    "genredeem","grantsub","bcast","totalusers","downloadusers","removesub","editsearch"
]))
def text_handler(client, message):
    uid = ensure_user(message.from_user)
    awaiting, state, sdata = get_state(uid)
    text = message.text.strip()
    log(f"Text from {uid} state={state} awaiting={awaiting}: {text}")

    # If awaiting a direct search (from button flow)
    if awaiting == 1 and state in ("", "search"):
        num = re.findall(r"\d{6,15}", text)
        if not num:
            message.reply_text("❌ Invalid number. Send 6–15 digits. Example: 911234567890")
            return
        cur.execute("UPDATE user_states SET awaiting_search=0, state='', state_data='' WHERE user_id=?", (uid,))
        conn.commit()
        perform_search(uid, message, num[0])
        return

    # Redeem via button-state (now per-user enforcement)
    if state == "await_redeem":
        code = text.split()[0].strip()
        cur.execute("SELECT max_uses, uses, reward FROM redeem_codes WHERE code=?", (code,))
        r = cur.fetchone()
        if not r:
            message.reply_text("❌ Invalid code.")
            clear_state(uid)
            return
        max_uses, uses, reward = r
        cur.execute("SELECT 1 FROM redeem_uses WHERE code=? AND user_id=?", (code, uid))
        if cur.fetchone():
            message.reply_text("⚠️ You have already used this code.")
            clear_state(uid)
            return
        if uses >= max_uses:
            message.reply_text("⚠️ Code used up.")
            clear_state(uid)
            return
        cur.execute("INSERT INTO redeem_uses (code, user_id, used_at) VALUES (?, ?, ?)", (code, uid, datetime.utcnow().isoformat()))
        cur.execute("UPDATE redeem_codes SET uses=uses+1 WHERE code=?", (code,))
        cur.execute("UPDATE users SET premium_searches=premium_searches+? WHERE id=?", (reward, uid))
        conn.commit()
        message.reply_text(f"✅ Code redeemed! {reward} premium searches added.")
        clear_state(uid)
        return

    # Admin: Add admin via manual state
    if state == "admin_addadmin":
        if not is_admin(uid):
            message.reply_text("Access denied.")
            clear_state(uid)
            return
        parts = text.split()
        try:
            nid = int(parts[0])
        except:
            message.reply_text("Invalid user id. Send numeric user id.")
            return
        cur.execute("INSERT OR IGNORE INTO admins (id) VALUES (?)", (nid,))
        conn.commit()
        message.reply_text(f"✅ Admin added: {nid}")
        log(f"Admin {nid} added by {uid}")
        clear_state(uid)
        return

    # Admin: Remove admin - text fallback
    if state == "admin_removeadmin":
        if not is_admin(uid):
            message.reply_text("Access denied.")
            clear_state(uid)
            return
        try:
            rid = int(text.split()[0])
        except:
            message.reply_text("Invalid user id.")
            return
        if rid == ADMIN_ID:
            message.reply_text("❌ Cannot remove main admin.")
            clear_state(uid)
            return
        if uid != ADMIN_ID:
            message.reply_text("❌ Only main admin can remove admins.")
            clear_state(uid)
            return
        cur.execute("DELETE FROM admins WHERE id=?", (rid,))
        conn.commit()
        message.reply_text(f"🗑️ Admin removed: {rid}")
        try:
            app.send_message(rid, f"⚠️ You have been removed as admin by {uid}.")
        except:
            pass
        log(f"Admin {rid} removed by {uid}")
        clear_state(uid)
        return

    # Admin: Grant Sub - manual entry "<user_id> <days>"
    if state == "admin_grantsub":
        if not is_admin(uid):
            message.reply_text("Access denied.")
            clear_state(uid)
            return
        parts = text.split()
        if len(parts) < 2:
            message.reply_text("Usage: <user_id> <days>  (example: 123456789 30)")
            return
        try:
            target = int(parts[0]); days = int(parts[1])
        except:
            message.reply_text("Invalid format. Both user_id and days must be integers.")
            return
        until = datetime.utcnow() + timedelta(days=days)
        cur.execute("INSERT OR IGNORE INTO users (id, username, first_name, registered_at, last_reset) VALUES (?, '', '', ?, ?)",
                    (target, datetime.utcnow().isoformat(), date.today().isoformat()))
        cur.execute("UPDATE users SET subscription_until=? WHERE id=?", (until.isoformat(), target))
        conn.commit()
        message.reply_text(f"💎 Subscription granted to {target} for {days} days (till {until.strftime('%Y-%m-%d')}).")
        try:
            app.send_message(target, f"💎 You’ve been granted a subscription for {days} days!")
        except:
            pass
        log(f"Grant sub to {target} for {days} days by {uid}")
        clear_state(uid)
        return

    # Admin: Remove Subscription via manual state
    if state == "admin_removesub":
        if not is_admin(uid):
            message.reply_text("Access denied.")
            clear_state(uid)
            return
        try:
            target = int(text.split()[0])
        except:
            message.reply_text("Invalid user id. Send numeric user id.")
            return
        cur.execute("UPDATE users SET subscription_until=NULL WHERE id=?", (target,))
        conn.commit()
        message.reply_text(f"✅ Subscription removed for {target}.")
        try:
            app.send_message(target, f"⚠️ Your subscription has been removed by admin {uid}.")
        except:
            pass
        log(f"Subscription removed for {target} by {uid}")
        clear_state(uid)
        return

    # Admin: Edit search - manual "<user_id> <count>"
    if state == "admin_editsearch":
        if not is_admin(uid):
            message.reply_text("Access denied.")
            clear_state(uid)
            return
        parts = text.split()
        if len(parts) < 2:
            message.reply_text("Usage: <user_id> <count>  (example: 123456789 10)")
            return
        try:
            target = int(parts[0]); count = int(parts[1])
        except:
            message.reply_text("Invalid args. Both must be integers.")
            return
        cur.execute("INSERT OR IGNORE INTO users (id, username, first_name, registered_at, last_reset) VALUES (?, '', '', ?, ?)",
                    (target, datetime.utcnow().isoformat(), date.today().isoformat()))
        cur.execute("UPDATE users SET premium_searches=? WHERE id=?", (count, target))
        conn.commit()
        message.reply_text(f"✅ premium_searches for {target} set to {count}.")
        try:
            app.send_message(target, f"ℹ️ Your premium search balance has been updated by admin to {count}.")
        except:
            pass
        log(f"Set premium_searches for {target} to {count} by {uid}")
        clear_state(uid)
        return

    # Admin: Gen Redeem via state
    if state == "admin_genredeem":
        if not is_admin(uid):
            message.reply_text("Access denied.")
            clear_state(uid)
            return
        parts = text.split()
        if len(parts) < 3:
            message.reply_text("Usage: <CODE> <max_uses> <reward>  (example: FREE100 100 5)")
            return
        code = parts[0]
        try:
            max_uses = int(parts[1]); reward = int(parts[2])
        except:
            message.reply_text("max_uses and reward must be integers.")
            return
        cur.execute("INSERT OR REPLACE INTO redeem_codes (code, max_uses, uses, reward, created_by, created_at) VALUES (?, ?, COALESCE((SELECT uses FROM redeem_codes WHERE code=?),0), ?, ?, ?)",
                    (code, max_uses, code, reward, uid, datetime.utcnow().isoformat()))
        conn.commit()
        message.reply_text(f"✅ Redeem created: {code} uses:{max_uses} reward:{reward}")
        log(f"Redeem {code} created by {uid} uses:{max_uses} reward:{reward}")
        clear_state(uid)
        return

    # Admin: Broadcast via state
    if state == "admin_bcast":
        if not is_admin(uid):
            message.reply_text("Access denied.")
            clear_state(uid)
            return
        if not text:
            message.reply_text("Send non-empty message to broadcast.")
            return
        cur.execute("SELECT id FROM users")
        users = [r[0] for r in cur.fetchall()]
        sent = 0
        for u in users:
            try:
                app.send_message(u, text)
                sent += 1
            except Exception:
                pass
        message.reply_text(f"✅ Broadcast sent to {sent}/{len(users)} users.")
        log(f"Broadcast by {uid} sent to {sent}/{len(users)} users")
        clear_state(uid)
        return

    # nothing matched
    message.reply_text("I didn't understand that. Use /help or press buttons.", reply_markup=main_menu(is_admin(uid)))

# ---------------- perform_search ----------------
def perform_search(uid, message, number):
    try:
        reset_daily(uid)
        cur.execute("SELECT premium_searches, subscription_until FROM users WHERE id=?", (uid,))
        r = cur.fetchone()
        if not r:
            cur.execute("INSERT OR IGNORE INTO users (id, username, first_name, registered_at, last_reset) VALUES (?, '', '', ?, ?)",
                        (uid, datetime.utcnow().isoformat(), date.today().isoformat()))
            conn.commit()
            cur.execute("SELECT premium_searches, subscription_until FROM users WHERE id=?", (uid,))
            r = cur.fetchone()
        p = r[0] if r else 0
        sub = r[1] if r else None
        sub_active = sub and datetime.fromisoformat(sub) > datetime.utcnow()
        used = get_daily_used(uid)
        if not sub_active and used >= FREE_DAILY_LIMIT and p <= 0:
            message.reply_text("❌ Limit reached. Redeem code or contact admin.")
            return
        if not sub_active:
            if used < FREE_DAILY_LIMIT:
                increment_usage(uid)
            else:
                cur.execute("UPDATE users SET premium_searches=premium_searches-1 WHERE id=? AND premium_searches>0", (uid,))
                conn.commit()
        # call API
        try:
            res = requests.get(NUMBER_API_URL.format(number=number, key=API_KEY), timeout=10)
            if res.status_code == 200:
                data = res.json()
                out = [f"🔍 Result for {number}:"]
                if isinstance(data, dict):
                    for k, v in data.items():
                        out.append(f"• {k}: {v}")
                else:
                    out.append(str(data))
                message.reply_text("\n".join(out))
            else:
                message.reply_text("⚠️ API error. Try again later.")
        except Exception as api_e:
            log("API error: " + str(api_e))
            message.reply_text(f"⚠️ Lookup failed: {api_e}")
    except Exception as e:
        log("perform_search error: " + str(e))
        traceback.print_exc()
        message.reply_text("Search failed due to internal error.")

# ---------------- Commands: help, num, redeem, cancel ----------------
@app.on_message(filters.command("help"))
def help_cmd(client, message):
    uid = ensure_user(message.from_user)
    if is_admin(uid):
        text = (
            "🛠️ Admin Help (buttons + text)\n\n"
            "General: /start, /help, /num <number>, /redeem <code>, /cancel\n\n"
            "Admin text commands:\n"
            "/addadmin <id>, /removeadmin <id>, /admins\n"
            "/genredeem <code> <max_uses> <reward>, /grantsub <user_id> <days>, /removesub <user_id>\n"
            "/editsearch <user_id> <count>\n"
            "/bcast <message>, /totalusers, /downloadusers\n\n"
            "Or use the Admin Panel from the main menu for button-driven actions."
        )
    else:
        text = (
            "🤖 User Help\n\n"
            "/start - Open main menu\n"
            "/help - This message\n"
            "/num <number> - Manual lookup (example: /num 911234567890)\n"
            "/redeem <code> - Redeem code (example: /redeem FREE100)\n"
            "/cancel - Cancel current button flow\n\n"
            "Use the main menu buttons for quick actions."
        )
    message.reply_text(text)

@app.on_message(filters.command("num"))
def num_cmd(client, message):
    uid = ensure_user(message.from_user)
    args = message.text.split()
    if len(args) < 2:
        message.reply_text("Usage: /num <phonenumber>\nExample: /num 911234567890")
        return
    number = args[1]
    cur.execute("UPDATE user_states SET awaiting_search=0, state='', state_data='' WHERE user_id=?", (uid,))
    conn.commit()
    perform_search(uid, message, number)

@app.on_message(filters.command("redeem"))
def redeem_cmd(client, message):
    uid = ensure_user(message.from_user)
    args = message.text.split()
    if len(args) < 2:
        set_state(uid, "await_redeem", "")
        message.reply_text("🎫 Send redeem code now (or use /redeem <CODE>):", reply_markup=back_kb_to_main())
        return
    code = args[1].strip()
    cur.execute("SELECT max_uses, uses, reward FROM redeem_codes WHERE code=?", (code,))
    r = cur.fetchone()
    if not r:
        message.reply_text("❌ Invalid code.")
        return
    max_uses, uses, reward = r
    cur.execute("SELECT 1 FROM redeem_uses WHERE code=? AND user_id=?", (code, uid))
    if cur.fetchone():
        message.reply_text("⚠️ You have already used this code.")
        return
    if uses >= max_uses:
        message.reply_text("⚠️ Code already used up.")
        return
    cur.execute("INSERT INTO redeem_uses (code, user_id, used_at) VALUES (?, ?, ?)", (code, uid, datetime.utcnow().isoformat()))
    cur.execute("UPDATE redeem_codes SET uses=uses+1 WHERE code=?", (code,))
    cur.execute("UPDATE users SET premium_searches=premium_searches+? WHERE id=?", (reward, uid))
    conn.commit()
    message.reply_text(f"✅ Code redeemed! {reward} premium searches added.")

@app.on_message(filters.command("cancel"))
def cancel_cmd(client, message):
    uid = ensure_user(message.from_user)
    clear_state(uid)
    message.reply_text("✅ Operation cancelled.", reply_markup=main_menu(is_admin(uid)))

# ---------------- Admin text commands (mirror buttons) ----------------
@app.on_message(filters.command("addadmin"))
@admin_only
def add_admin_cmd(client, message):
    args = message.text.split()
    if len(args) < 2:
        message.reply_text("Usage: /addadmin <user_id>")
        return
    try:
        nid = int(args[1])
    except:
        message.reply_text("Invalid user id.")
        return
    cur.execute("INSERT OR IGNORE INTO admins (id) VALUES (?)", (nid,))
    conn.commit()
    message.reply_text(f"✅ Admin added: {nid}")
    log(f"Admin {nid} added by {message.from_user.id}")

@app.on_message(filters.command("removeadmin"))
@admin_only
def remove_admin_cmd(client, message):
    args = message.text.split()
    if len(args) < 2:
        message.reply_text("Usage: /removeadmin <user_id>")
        return
    try:
        rid = int(args[1])
    except:
        message.reply_text("Invalid user id.")
        return
    if rid == ADMIN_ID:
        message.reply_text("❌ Cannot remove main admin.")
        return
    if message.from_user.id != ADMIN_ID:
        message.reply_text("❌ Only the main admin can remove admins.")
        return
    cur.execute("DELETE FROM admins WHERE id=?", (rid,))
    conn.commit()
    message.reply_text(f"🗑️ Admin removed: {rid}")
    log(f"Admin {rid} removed by {message.from_user.id}")
    try:
        app.send_message(rid, f"⚠️ You have been removed as admin by {message.from_user.id}.")
    except:
        pass

@app.on_message(filters.command("admins"))
@admin_only
def admins_cmd(client, message):
    cur.execute("SELECT id FROM admins")
    rows = cur.fetchall()
    # show username if available
    lines = []
    for r in rows:
        a_id = r[0]
        cur.execute("SELECT username, first_name FROM users WHERE id=?", (a_id,))
        u = cur.fetchone()
        if u:
            uname = u[0] or ""
            fname = u[1] or ""
            label = f"{a_id}"
            if uname:
                label += f" (@{uname})"
            elif fname:
                label += f" ({fname})"
        else:
            label = str(a_id)
        lines.append(label)
    message.reply_text("👑 Admins:\n" + "\n".join(lines))

@app.on_message(filters.command("genredeem"))
@admin_only
def genredeem_cmd(client, message):
    args = message.text.split()
    if len(args) < 4:
        message.reply_text("Usage: /genredeem <code> <max_uses> <reward>\nExample: /genredeem FREE100 100 5")
        return
    code = args[1].strip()
    try:
        max_uses = int(args[2]); reward = int(args[3])
    except:
        message.reply_text("max_uses and reward must be integers.")
        return
    cur.execute("INSERT OR REPLACE INTO redeem_codes (code, max_uses, uses, reward, created_by, created_at) VALUES (?, ?, COALESCE((SELECT uses FROM redeem_codes WHERE code=?),0), ?, ?, ?)",
                (code, max_uses, code, reward, message.from_user.id, datetime.utcnow().isoformat()))
    conn.commit()
    message.reply_text(f"✅ Redeem created/updated: {code} uses:{max_uses} reward:{reward}")
    log(f"Redeem {code} created by {message.from_user.id} uses:{max_uses} reward:{reward}")

@app.on_message(filters.command("grantsub"))
@admin_only
def grantsub_cmd(client, message):
    args = message.text.split()
    if len(args) < 3:
        message.reply_text("Usage: /grantsub <user_id> <days>\nExample: /grantsub 123456789 30")
        return
    try:
        target = int(args[1]); days = int(args[2])
    except:
        message.reply_text("Invalid args.")
        return
    until = datetime.utcnow() + timedelta(days=days)
    cur.execute("INSERT OR IGNORE INTO users (id, username, first_name, registered_at, last_reset) VALUES (?, '', '', ?, ?)",
                (target, datetime.utcnow().isoformat(), date.today().isoformat()))
    cur.execute("UPDATE users SET subscription_until=? WHERE id=?", (until.isoformat(), target))
    conn.commit()
    message.reply_text(f"💎 Subscription granted to {target} for {days} days (till {until.strftime('%Y-%m-%d')}).")
    try:
        app.send_message(target, f"💎 You’ve been granted a subscription for {days} days!")
    except:
        pass
    log(f"Grant sub to {target} for {days} days by {message.from_user.id}")

@app.on_message(filters.command("removesub"))
@admin_only
def removesub_cmd(client, message):
    args = message.text.split()
    if len(args) < 2:
        message.reply_text("Usage: /removesub <user_id>")
        return
    try:
        target = int(args[1])
    except:
        message.reply_text("Invalid user id.")
        return
    cur.execute("UPDATE users SET subscription_until=NULL WHERE id=?", (target,))
    conn.commit()
    message.reply_text(f"✅ Subscription removed for {target}.")
    try:
        app.send_message(target, f"⚠️ Your subscription has been removed by admin {message.from_user.id}.")
    except:
        pass
    log(f"Subscription removed for {target} by {message.from_user.id}")

@app.on_message(filters.command("editsearch"))
@admin_only
def editsearch_cmd(client, message):
    args = message.text.split()
    if len(args) < 3:
        message.reply_text("Usage: /editsearch <user_id> <count>")
        return
    try:
        target = int(args[1]); count = int(args[2])
    except:
        message.reply_text("Invalid args.")
        return
    cur.execute("INSERT OR IGNORE INTO users (id, username, first_name, registered_at, last_reset) VALUES (?, '', '', ?, ?)",
                (target, datetime.utcnow().isoformat(), date.today().isoformat()))
    cur.execute("UPDATE users SET premium_searches=? WHERE id=?", (count, target))
    conn.commit()
    message.reply_text(f"✅ premium_searches for {target} set to {count}.")
    try:
        app.send_message(target, f"ℹ️ Your premium search balance has been updated by admin to {count}.")
    except:
        pass
    log(f"Set premium_searches for {target} to {count} by {message.from_user.id}")

@app.on_message(filters.command("bcast"))
@admin_only
def bcast_cmd(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        message.reply_text("Usage: /bcast <message>")
        return
    text = args[1]
    cur.execute("SELECT id FROM users")
    users = [r[0] for r in cur.fetchall()]
    sent = 0
    for u in users:
        try:
            app.send_message(u, text)
            sent += 1
        except:
            pass
    message.reply_text(f"✅ Broadcast sent to {sent}/{len(users)} users.")
    log(f"Broadcast by {message.from_user.id} sent to {sent}/{len(users)} users")

@app.on_message(filters.command("totalusers"))
@admin_only
def totalusers_cmd(client, message):
    cur.execute("SELECT COUNT(*) FROM users")
    total = cur.fetchone()[0]
    message.reply_text(f"👥 Total users: {total}")

@app.on_message(filters.command("downloadusers"))
@admin_only
def downloadusers_cmd(client, message):
    cur.execute("SELECT id, username, first_name, registered_at, premium_searches, subscription_until, total_searches FROM users ORDER BY id ASC")
    rows = cur.fetchall()
    if not rows:
        message.reply_text("No users to export.")
        return
    try:
        tmp = tempfile.NamedTemporaryFile(delete=False, mode="w", encoding="utf-8", suffix=".txt", prefix="users_export_")
        path = tmp.name
        for r in rows:
            uid_r = r[0]
            username = r[1] or "-"
            first_name = r[2] or "-"
            reg = r[3] or "-"
            premium = r[4] or 0
            sub = r[5] or "None"
            total_s = r[6] or 0
            tmp.write(f"{uid_r} | @{username} | {first_name} | registered:{reg} | premium:{premium} | subscription:{sub} | total:{total_s}\n")
        tmp.flush()
        tmp.close()
    except Exception as e:
        log(f"Failed to create export file: {e}")
        message.reply_text("❌ Failed to create export file.")
        return
    try:
        try:
            message.reply_document(path, caption=f"Users export ({len(rows)} rows).")
        except Exception:
            app.send_document(message.from_user.id, path, caption=f"Users export ({len(rows)} rows).")
        log(f"Users TXT exported and sent to {message.from_user.id}, path={path}")
    except Exception as e:
        log(f"Failed to send TXT to {message.from_user.id}: {e}")
        message.reply_text("❌ Failed to send TXT.")
    finally:
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception as e:
            log(f"Failed to remove temp file {path}: {e}")

# ---------------- Run ----------------
if __name__ == "__main__":
    log("Starting modified bot (UI/flows updated per request).")
    app.run()