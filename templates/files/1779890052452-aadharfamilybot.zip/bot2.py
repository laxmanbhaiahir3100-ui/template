import logging
import json
import os
import httpx
from datetime import datetime

from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)

from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    CallbackQueryHandler,
)

# ===================== CONFIG =====================

BOT_TOKEN = "PASTE_YOUR_BOT_TOKEN"

AADHAAR_API_KEY = "PASTE_YOUR_AADHAR_API"
FAMILY_API_KEY = "PASTE_YOUR_FAMILY_API"

AADHAAR_API_URL = "https://numinfo.eu.cc/api/aadhaar"
FAMILY_API_URL = "https://numinfo.eu.cc/api/family"

ADMIN_ID = 1386134836

# ===================== CHANNELS =====================

CHANNEL_1_ID = "@hostmafia_in"
CHANNEL_1_LINK = "https://t.me/hostmafia_in"
CHANNEL_1_NAME = "HOSTMAFIA"

CHANNEL_2_ID = "@modverse_online"
CHANNEL_2_LINK = "https://t.me/modverse_online"
CHANNEL_2_NAME = "MODVERSE"

CHANNEL_3_ID = "@lakhan_backup"
CHANNEL_3_LINK = "https://t.me/lakhan_backup"
CHANNEL_3_NAME = "BACKUP"

# ===================== FILES =====================

USERS_FILE = "users.json"
BANNED_FILE = "banned.json"

# ===================== LOGGING =====================

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)

logger = logging.getLogger(__name__)

# ===================== HELPERS =====================

def load_json(filename, default):
    if os.path.exists(filename):
        with open(filename, "r") as f:
            return json.load(f)
    return default


def save_json(filename, data):
    with open(filename, "w") as f:
        json.dump(data, f, indent=2)


def load_users():
    return load_json(USERS_FILE, {})


def save_users(data):
    save_json(USERS_FILE, data)


def load_banned():
    return load_json(BANNED_FILE, [])


def save_banned(data):
    save_json(BANNED_FILE, data)


def is_admin(user_id):
    return user_id == ADMIN_ID


def is_banned(user_id):
    banned = load_banned()
    return str(user_id) in [str(x) for x in banned]


def register_user(user):

    users = load_users()

    uid = str(user.id)

    new_user = uid not in users

    users[uid] = {
        "id": user.id,
        "username": user.username or "No Username",
        "name": user.first_name or "Unknown",
        "joined": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    save_users(users)

    return new_user

# ===================== BUTTONS =====================

def join_buttons():

    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                f"📢 {CHANNEL_1_NAME}",
                url=CHANNEL_1_LINK
            ),
            InlineKeyboardButton(
                f"📢 {CHANNEL_2_NAME}",
                url=CHANNEL_2_LINK
            ),
        ],
        [
            InlineKeyboardButton(
                f"📢 {CHANNEL_3_NAME}",
                url=CHANNEL_3_LINK
            )
        ],
        [
            InlineKeyboardButton(
                "✅ Verify Join",
                callback_data="verify_join"
            )
        ]
    ])


def normal_buttons():

    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                f"📢 {CHANNEL_1_NAME}",
                url=CHANNEL_1_LINK
            ),
            InlineKeyboardButton(
                f"📢 {CHANNEL_2_NAME}",
                url=CHANNEL_2_LINK
            ),
        ],
        [
            InlineKeyboardButton(
                f"📢 {CHANNEL_3_NAME}",
                url=CHANNEL_3_LINK
            )
        ]
    ])

# ===================== FORCE JOIN =====================

async def is_member(bot, user_id, channel):

    try:

        member = await bot.get_chat_member(channel, user_id)

        print(f"{channel} => {member.status}")

        return member.status in [
            "member",
            "administrator",
            "creator",
            "restricted"
        ]

    except Exception as e:

        print(f"CHANNEL ERROR => {channel} => {e}")

        return False


async def force_join(update, context):

    user_id = update.effective_user.id

    if is_admin(user_id):
        return True

    if is_banned(user_id):

        await update.message.reply_text(
            "🚫 You are banned from this bot.\n\n@lakhan_lakhnotra",
            reply_markup=normal_buttons()
        )

        return False

    bot = context.bot

    joined1 = await is_member(bot, user_id, CHANNEL_1_ID)
    joined2 = await is_member(bot, user_id, CHANNEL_2_ID)
    joined3 = await is_member(bot, user_id, CHANNEL_3_ID)

    print(f"JOIN STATUS => {joined1}, {joined2}, {joined3}")

    if joined1 and joined2 and joined3:
        return True

    not_joined = []

    if not joined1:
        not_joined.append(CHANNEL_1_NAME)

    if not joined2:
        not_joined.append(CHANNEL_2_NAME)

    if not joined3:
        not_joined.append(CHANNEL_3_NAME)

    text = (
        "❌ You must join all channels first.\n\n"
        f"🚫 Not Joined: {', '.join(not_joined)}\n\n"
        "After joining click Verify Join.\n\n"
        "@lakhan_lakhnotra"
    )

    if update.message:

        await update.message.reply_text(
            text,
            reply_markup=join_buttons()
        )

    return False


async def verify_callback(update, context):

    query = update.callback_query

    await query.answer()

    user_id = query.from_user.id

    bot = context.bot

    joined1 = await is_member(bot, user_id, CHANNEL_1_ID)
    joined2 = await is_member(bot, user_id, CHANNEL_2_ID)
    joined3 = await is_member(bot, user_id, CHANNEL_3_ID)

    print(f"VERIFY STATUS => {joined1}, {joined2}, {joined3}")

    if joined1 and joined2 and joined3:

        try:

            await query.edit_message_text(
                "✅ Verification Successful.\n\n"
                "You can now use the bot.\n\n"
                "@lakhan_lakhnotra",
                reply_markup=normal_buttons()
            )

        except Exception as e:

            print(f"VERIFY SUCCESS ERROR => {e}")

    else:

        not_joined = []

        if not joined1:
            not_joined.append(CHANNEL_1_NAME)

        if not joined2:
            not_joined.append(CHANNEL_2_NAME)

        if not joined3:
            not_joined.append(CHANNEL_3_NAME)

        text = (
            "❌ You still haven't joined all channels.\n\n"
            f"🚫 Not Joined: {', '.join(not_joined)}\n\n"
            "@lakhan_lakhnotra"
        )

        try:

            await query.edit_message_text(
                text,
                reply_markup=join_buttons()
            )

        except Exception as e:

            print(f"VERIFY FAIL ERROR => {e}")

# ===================== START =====================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):

    if not await force_join(update, context):
        return

    user = update.effective_user

    new_user = register_user(user)

    if new_user:

        users = load_users()

        total = len(users)

        text = (
            f"🆕 New User Joined\n\n"
            f"👤 Name: {user.first_name}\n"
            f"🔗 Username: @{user.username}\n"
            f"🆔 ID: {user.id}\n"
            f"📊 Total Users: {total}\n\n"
            f"@lakhan_lakhnotra"
        )

        try:
            await context.bot.send_message(
                chat_id=ADMIN_ID,
                text=text
            )
        except:
            pass

    msg = (
        "🔍 Welcome to Aadhaar Bot\n\n"
        "━━━━━━━━━━━━━━━\n"
        "📌 Available Commands\n\n"
        "/aadhar <aadhaar>\n"
        "/family <aadhaar>\n"
        "/help\n\n"
        "━━━━━━━━━━━━━━━\n"
        "⚡ Powered By @lakhan_lakhnotra"
    )

    await update.message.reply_text(
        msg,
        reply_markup=normal_buttons()
    )

# ===================== HELP =====================

async def help_command(update, context):

    if not await force_join(update, context):
        return

    text = (
        "📖 Help Menu\n\n"
        "👤 User Commands:\n\n"
        "/start - Start Bot\n"
        "/aadhar <number>\n"
        "/family <number>\n"
        "/help\n\n"
        "⚡ @lakhan_lakhnotra"
    )

    await update.message.reply_text(
        text,
        reply_markup=normal_buttons()
    )

# ===================== AADHAAR =====================

async def aadhar_command(update, context):

    if not await force_join(update, context):
        return

    if not context.args:

        await update.message.reply_text(
            "Usage:\n/aadhar 123456789012\n\n@lakhan_lakhnotra",
            reply_markup=normal_buttons()
        )

        return

    aadhaar = context.args[0]

    searching = await update.message.reply_text(
        "🔍 Searching Aadhaar...\n\n@lakhan_lakhnotra",
        reply_markup=normal_buttons()
    )

    try:

        params = {
            "apikey": AADHAAR_API_KEY,
            "aadhaar": aadhaar
        }

        async with httpx.AsyncClient(timeout=30) as client:

            response = await client.get(
                AADHAAR_API_URL,
                params=params
            )

            try:
                data = response.json()
            except:
                data = {
                    "error": response.text
                }

        pretty = json.dumps(
            data,
            indent=2,
            ensure_ascii=False
        )

        await searching.delete()

        chunks = [
            pretty[i:i+3500]
            for i in range(0, len(pretty), 3500)
        ]

        for chunk in chunks:

            safe_chunk = chunk.replace("<", "&lt;").replace(">", "&gt;")

            await update.message.reply_text(
                f"<pre>{safe_chunk}</pre>\n\n@lakhan_lakhnotra",
                parse_mode="HTML",
                reply_markup=normal_buttons()
            )

    except Exception as e:

        await searching.edit_text(
            f"❌ Error:\n{str(e)}\n\n@lakhan_lakhnotra",
            reply_markup=normal_buttons()
        )

# ===================== FAMILY =====================

async def family_command(update, context):

    if not await force_join(update, context):
        return

    if not context.args:

        await update.message.reply_text(
            "Usage:\n/family 123456789012\n\n@lakhan_lakhnotra",
            reply_markup=normal_buttons()
        )

        return

    aadhaar = context.args[0]

    searching = await update.message.reply_text(
        "🔍 Searching Family...\n\n@lakhan_lakhnotra",
        reply_markup=normal_buttons()
    )

    try:

        params = {
            "apikey": FAMILY_API_KEY,
            "aadhaar": aadhaar
        }

        async with httpx.AsyncClient(timeout=30) as client:

            response = await client.get(
                FAMILY_API_URL,
                params=params
            )

            try:
                data = response.json()
            except:
                data = {
                    "error": response.text
                }

        pretty = json.dumps(
            data,
            indent=2,
            ensure_ascii=False
        )

        await searching.delete()

        chunks = [
            pretty[i:i+3500]
            for i in range(0, len(pretty), 3500)
        ]

        for chunk in chunks:

            safe_chunk = chunk.replace("<", "&lt;").replace(">", "&gt;")

            await update.message.reply_text(
                f"<pre>{safe_chunk}</pre>\n\n@lakhan_lakhnotra",
                parse_mode="HTML",
                reply_markup=normal_buttons()
            )

    except Exception as e:

        await searching.edit_text(
            f"❌ Error:\n{str(e)}\n\n@lakhan_lakhnotra",
            reply_markup=normal_buttons()
        )

# ===================== ADMIN =====================

async def commands_command(update, context):

    if not is_admin(update.effective_user.id):
        return

    text = (
        "🛠 Admin Commands\n\n"
        "/commands\n"
        "/users\n"
        "/ban <id>\n"
        "/unban <id>\n"
        "/bcast <message>\n\n"
        "@lakhan_lakhnotra"
    )

    await update.message.reply_text(
        text,
        reply_markup=normal_buttons()
    )

async def users_command(update, context):

    if not is_admin(update.effective_user.id):
        return

    users = load_users()

    text = f"👥 Total Users: {len(users)}\n\n"

    for uid, info in users.items():

        text += (
            f"👤 {info['name']}\n"
            f"🔗 @{info['username']}\n"
            f"🆔 {uid}\n\n"
        )

    await update.message.reply_text(
        text[:4000],
        reply_markup=normal_buttons()
    )

async def ban_command(update, context):

    if not is_admin(update.effective_user.id):
        return

    if not context.args:
        return

    uid = context.args[0]

    banned = load_banned()

    if uid not in banned:
        banned.append(uid)

    save_banned(banned)

    await update.message.reply_text(
        f"🚫 Banned: {uid}\n\n@lakhan_lakhnotra",
        reply_markup=normal_buttons()
    )

async def unban_command(update, context):

    if not is_admin(update.effective_user.id):
        return

    if not context.args:
        return

    uid = context.args[0]

    banned = load_banned()

    banned = [x for x in banned if str(x) != str(uid)]

    save_banned(banned)

    await update.message.reply_text(
        f"✅ Unbanned: {uid}\n\n@lakhan_lakhnotra",
        reply_markup=normal_buttons()
    )

async def bcast_command(update, context):

    if not is_admin(update.effective_user.id):
        return

    if not context.args:
        return

    msg = " ".join(context.args)

    users = load_users()

    success = 0

    for uid in users:

        try:

            await context.bot.send_message(
                chat_id=int(uid),
                text=f"{msg}\n\n@lakhan_lakhnotra",
                reply_markup=normal_buttons()
            )

            success += 1

        except:
            pass

    await update.message.reply_text(
        f"✅ Broadcast Sent To {success} Users\n\n@lakhan_lakhnotra",
        reply_markup=normal_buttons()
    )

# ===================== MAIN =====================

def main():

    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("aadhar", aadhar_command))
    app.add_handler(CommandHandler("family", family_command))

    app.add_handler(CommandHandler("commands", commands_command))
    app.add_handler(CommandHandler("users", users_command))
    app.add_handler(CommandHandler("ban", ban_command))
    app.add_handler(CommandHandler("unban", unban_command))
    app.add_handler(CommandHandler("bcast", bcast_command))

    app.add_handler(
        CallbackQueryHandler(
            verify_callback,
            pattern="^verify_join$"
        )
    )

    logger.info("🤖 Bot Running...")

    app.run_polling(
        allowed_updates=Update.ALL_TYPES
    )

if __name__ == "__main__":
    main()
